import React, { useEffect, useState, useRef, lazy, Suspense, useMemo, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { AnimatePresence, motion } from 'framer-motion';
import useAppStore from './store/appStore';
import { GAMES } from './constants';
import { initTelegramWebApp, getTelegramUser, verifyTelegramSession, getStartParam, getTelegramWebApp } from './lib/telegram';
import { warmSession } from './lib/session';
import { trackVisitor } from './manager/lib/managerDb';
import SplashScreen from './components/SplashScreen';
import Navbar from './components/Navbar';
import BottomNav from './components/BottomNav';
import NotificationSystem from './components/NotificationSystem';
import AdminAnnouncementBanner from './components/AdminAnnouncementBanner';
import AppErrorBoundary from './components/AppErrorBoundary';
import Dashboard from './pages/Dashboard';
import { SkeletonCard, SkeletonRow } from './components/Skeleton';

function PageSkeleton() {
  return (
    <div style={{ padding: '20px 16px', display: 'flex', flexDirection: 'column', gap: 12 }}>
      <SkeletonCard height={100} />
      <SkeletonCard height={80} />
      {[0,1,2,3].map(i => <SkeletonRow key={i} />)}
    </div>
  );
}

const Games        = lazy(() => import('./pages/Games'));
const Contests     = lazy(() => import('./pages/Contests'));
const Leaderboard  = lazy(() => import('./pages/Leaderboard'));
const Wallet       = lazy(() => import('./pages/Wallet'));
const Referral     = lazy(() => import('./pages/Referral'));
const Achievements = lazy(() => import('./pages/Achievements'));
import GameModal from './components/games/GameModal';

function MaintenanceScreen({ appConfig }) {
  const title = appConfig?.app_title || 'Skill Games';
  return (
    <div style={{ position: 'fixed', inset: 0, background: '#04030a', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: 32, textAlign: 'center', gap: 20 }}>
      <div style={{ fontSize: 56 }}>🔧</div>
      <h1 style={{ fontFamily: 'Orbitron, sans-serif', fontSize: 20, fontWeight: 900, color: '#fff', letterSpacing: '0.05em' }}>{title}</h1>
      <p style={{ fontSize: 14, color: 'rgba(148,163,184,0.75)', lineHeight: 1.6, maxWidth: 280 }}>
        We are performing scheduled maintenance. We will be back shortly!
      </p>
      <div style={{ marginTop: 8, padding: '8px 20px', borderRadius: 99, background: 'rgba(245,158,11,0.12)', border: '1px solid rgba(245,158,11,0.35)' }}>
        <span style={{ fontSize: 11, color: '#f59e0b', fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase' }}>Under Maintenance</span>
      </div>
    </div>
  );
}

class GameModalErrorBoundary extends React.Component {
  constructor(props) { super(props); this.state = { hasError: false, msg: '', stack: '' }; }
  static getDerivedStateFromError(e) { return { hasError: true, msg: e?.message || String(e), stack: e?.stack?.split('\n').slice(0,5).join('\n') || '' }; }
  componentDidCatch(e, info) { if (import.meta.env.DEV) console.error('[GameModalError]', e, info?.componentStack); }
  render() {
    if (this.state.hasError) {
      return (
        <div style={{ position: 'fixed', inset: 0, zIndex: 9999, background: 'rgba(0,0,0,0.92)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24 }}>
          <div style={{ maxWidth: 340, textAlign: 'center', padding: 28, borderRadius: 20, background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)' }}>
            <div style={{ fontSize: 42, marginBottom: 14, color: '#fbbf24' }}>!</div>
            <p style={{ fontSize: 16, fontWeight: 800, color: '#fff', marginBottom: 8 }}>Could not open game</p>
            <p style={{ fontSize: 13, color: 'rgba(148,163,184,0.75)', marginBottom: 20, lineHeight: 1.5 }}>
              Please try again. If the problem persists, close and reopen the app.
            </p>
            {this.state.msg && <p style={{ fontSize: 12, color: 'rgba(239,68,68,0.8)', marginBottom: 8, wordBreak: 'break-all', textAlign: 'left' }}>{this.state.msg}</p>}
            {this.state.stack && <pre style={{ fontSize: 9, color: 'rgba(148,163,184,0.5)', marginBottom: 14, wordBreak: 'break-all', textAlign: 'left', whiteSpace: 'pre-wrap' }}>{this.state.stack}</pre>}
            <button
              onClick={() => { this.setState({ hasError: false, msg: '', stack: '' }); this.props.onClose?.(); }}
              style={{ padding: '12px 28px', borderRadius: 14, background: 'linear-gradient(135deg, #06b6d4, #0ea5e9)', color: '#fff', fontWeight: 800, border: 'none', cursor: 'pointer', fontSize: 14 }}
            >
              Close
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

const isSlowDevice = document.documentElement.classList.contains('device-low') || document.documentElement.classList.contains('device-mid');
// No exit animation — new page overlaps immediately so there's never a blank frame.
// Only animate entrance (fade in). Exit is instant (opacity:1, no transition).
const pageVariants = isSlowDevice
  ? { initial: {}, animate: {}, exit: {} }
  : {
      initial: { opacity: 0 },
      animate: { opacity: 1, transition: { duration: 0.15, ease: 'easeOut' } },
      exit:    { opacity: 1 }, // stay visible — new page fades in on top
    };

const PAGES = { dashboard: Dashboard, games: Games, contests: Contests, leaderboard: Leaderboard, wallet: Wallet, referral: Referral, achievements: Achievements };

export default function App() {
  const [appReady, setAppReady] = useState(false);
  const [openGame, setOpenGame] = useState(null);
  const [openGameTiers, setOpenGameTiers] = useState(null);
  const [pendingRoom, setPendingRoom] = useState(null);
  const currentPage        = useAppStore(s => s.currentPage);
  const appConfig          = useAppStore(s => s.appConfig);
  const setUser            = useAppStore(s => s.setUser);
  const setCurrentPage     = useAppStore(s => s.setCurrentPage);
  const setPwaInstallPrompt = useAppStore(s => s.setPwaInstallPrompt);
  const loadRemoteConfig   = useAppStore(s => s.loadRemoteConfig);
  const refreshBalance     = useAppStore(s => s.refreshBalance);
  const subscribeBalance   = useAppStore(s => s.subscribeBalance);
  const unsubscribeBalance = useAppStore(s => s.unsubscribeBalance);

  // Track the last handled start_param to avoid processing the same deeplink twice
  const lastHandledSpRef = useRef('');
  const openGameRef = useRef(openGame);
  openGameRef.current = openGame;

  const handleBack = useCallback(() => {
    if (openGameRef.current) {
      setOpenGame(null);
      setPendingRoom(null);
      refreshBalance();
    } else if (currentPage !== 'dashboard') {
      setCurrentPage('dashboard');
    }
  }, [currentPage, refreshBalance, setCurrentPage]);

  const handleBackRef = useRef(handleBack);
  handleBackRef.current = handleBack;

  // Sync Telegram BackButton with app navigation state
  useEffect(() => {
    const wa = getTelegramWebApp();
    if (!wa?.BackButton) return;
    const bb = wa.BackButton;
    const shouldShow = openGame !== null || currentPage !== 'dashboard';
    if (shouldShow) {
      bb.show();
    } else {
      bb.hide();
    }
    const handleBack = handleBackRef.current;
    bb.onClick(handleBack);
    return () => { bb.offClick(handleBack); };
  }, [currentPage, openGame]);

  function handleStartParam(sp) {
    if (!sp || sp === lastHandledSpRef.current) return;
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('contest') || sp.startsWith('contest_')) {
      lastHandledSpRef.current = sp;
      setCurrentPage('contests');
    } else if (sp.startsWith('room_')) {
      const parts = sp.slice(5).split('_');
      if (parts.length >= 2) {
        const roomId = parts[0];
        const gameId = Number(parts[1]);
        const roomType = parts[2] || 'pvp';
        const game = GAMES.find(g => g.id === gameId);
        if (game && roomId) {
          lastHandledSpRef.current = sp;
          if (openGameRef.current && Number(openGameRef.current.id) !== gameId) {
            setOpenGame(null);
            setPendingRoom(null);
          }
          setPendingRoom({ roomId, gameId, roomType });
          setOpenGame(game);
          setCurrentPage('games');
        }
      }
    }
  }

  useEffect(() => {
    const onInstallPrompt = (e) => { e.preventDefault(); setPwaInstallPrompt(e); };
    window.addEventListener('beforeinstallprompt', onInstallPrompt);

    const wa = initTelegramWebApp();

    // Fire all independent init tasks in parallel — don't await sequentially
    loadRemoteConfig();
    warmSession(); // warms session cache so first game action is instant

    // Handle deeplink on initial load
    const urlParams = new URLSearchParams(window.location.search);
    const sp = getStartParam() || urlParams.get('startapp') || '';
    handleStartParam(sp);
    if (!sp && urlParams.get('contest')) {
      setCurrentPage('contests');
    }

    const tgUser = getTelegramUser();
    if (tgUser) {
      const normalized = {
        ...tgUser,
        telegram_id: tgUser.telegram_id || tgUser.id,
      };
      setUser(normalized);
      trackVisitor(normalized);
    }

    verifyTelegramSession()
      .then((session) => {
        if (session?.telegram_id) {
          const u = useAppStore.getState().user || {};
          setUser({
            ...u,
            telegram_id: session.telegram_id,
            first_name: u.first_name || session.user?.first_name || 'Player',
            username:   u.username   || session.user?.username   || 'player',
          });
        }
        // refreshBalance and subscribeBalance in parallel
        Promise.all([refreshBalance(), Promise.resolve(subscribeBalance())]).catch(() => {});
      })
      .catch(() => {});

    let vhTimer = null;
    let recalc = null;
    if (wa) {
      recalc = () => {
        clearTimeout(vhTimer);
        vhTimer = setTimeout(() => {
          document.documentElement.style.setProperty('--tg-viewport-height', `${wa.viewportHeight || window.innerHeight}px`);
        }, 250);
      };
      recalc();
      try { wa.onEvent('viewportChanged', recalc); } catch { /* ignore */ }
    } else {
      document.documentElement.style.setProperty('--tg-viewport-height', `${window.innerHeight}px`);
    }

    // Re-check start_param when the app comes back to foreground.
    // Telegram sometimes doesn't reload the Mini App when a startapp link is
    // tapped while the app is already open — it just brings it back to front
    // without changing the URL. In that case the new start_param is available
    // in initDataUnsafe but the initial useEffect has already run.
    const onVis = () => {
      document.body.classList.toggle('is-hidden', document.hidden);
      if (!document.hidden) {
        const freshSp = getStartParam();
        if (freshSp && freshSp !== lastHandledSpRef.current) {
          handleStartParam(freshSp);
        }
      }
    };
    document.addEventListener('visibilitychange', onVis);

    return () => {
      clearTimeout(vhTimer);
      if (wa && recalc) { try { wa.offEvent('viewportChanged', recalc); } catch { /* ignore */ } }
      document.removeEventListener('visibilitychange', onVis);
      window.removeEventListener('beforeinstallprompt', onInstallPrompt);
      unsubscribeBalance();
    };
  }, []);

  const Page = useMemo(() => PAGES[currentPage] || Dashboard, [currentPage]);
  const inMaintenance = useMemo(() => appConfig?.maintenance_mode === true, [appConfig]);

  return (
    <div className="app-shell text-white select-none" style={{ background: '#04030a' }}>
      <AnimatePresence initial={false}>{!appReady && <SplashScreen onDone={() => setAppReady(true)} />}</AnimatePresence>

      {appReady && inMaintenance && <MaintenanceScreen appConfig={appConfig} />}

      {appReady && !inMaintenance && (
        <>
          <NotificationSystem />
          <AdminAnnouncementBanner />
          <Navbar />
          <main className="scroll-area max-w-xl mx-auto w-full">
            <AppErrorBoundary>
              {/* No mode="wait" — new page fades in immediately over old page, zero blank frames */}
              <AnimatePresence initial={false}>
                <motion.div
                  key={currentPage}
                  variants={pageVariants}
                  initial="initial"
                  animate="animate"
                  exit="exit"
                  style={{ position: 'relative' }}
                >
                  <Suspense fallback={<PageSkeleton />}>
                    <Page onOpenGame={(g, tiers) => { setOpenGame(g); setOpenGameTiers(tiers || null); }} />
                  </Suspense>
                </motion.div>
              </AnimatePresence>
            </AppErrorBoundary>
          </main>
          <BottomNav />
        </>
      )}

      {openGame && createPortal(
        <GameModalErrorBoundary key={openGame.id} onClose={() => { setOpenGame(null); setPendingRoom(null); setOpenGameTiers(null); }}>
          <GameModal
            game={openGame}
            prefetchedTiers={openGameTiers}
            initialJoinCode={Number(pendingRoom?.gameId) === Number(openGame.id) ? pendingRoom.roomId : null}
            initialRoomType={Number(pendingRoom?.gameId) === Number(openGame.id) ? (pendingRoom.roomType || 'pvp') : null}
            onClose={() => { setOpenGame(null); setPendingRoom(null); setOpenGameTiers(null); refreshBalance(); }}
          />
        </GameModalErrorBoundary>,
        document.body
      )}
    </div>
  );
}
