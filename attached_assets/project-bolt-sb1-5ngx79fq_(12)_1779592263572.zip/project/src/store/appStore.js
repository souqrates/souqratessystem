import { create } from 'zustand';
import { supabase } from '../lib/supabase';
import { GAMES } from '../constants';
import { getBalance, getSoloFeeTiers } from '../lib/payments';

function parseConfigRows(rows, target = {}) {
  (rows || []).forEach(({ key, value, type }) => {
    if (type === 'boolean') target[key] = value === 'true';
    else if (type === 'number') target[key] = Number(value);
    else target[key] = value;
  });
  return target;
}

async function fetchAppConfig() {
  const { data } = await supabase.from('manager_config').select('key,value,type');
  return parseConfigRows(data);
}

async function fetchStagingConfig() {
  const { data } = await supabase.from('manager_preview_config').select('key,value,type');
  return data || [];
}

async function fetchGameOverrides() {
  const { data } = await supabase.from('manager_games').select('*');
  if (!data) return {};
  const map = {};
  data.forEach(o => { map[o.game_id] = o; });
  return map;
}

async function fetchStagingGames() {
  const { data } = await supabase.from('manager_preview_games').select('*');
  if (!data) return {};
  const map = {};
  data.forEach(o => { map[o.game_id] = o; });
  return map;
}

function mergeGameOverrides(live, staging) {
  const merged = { ...live };
  Object.entries(staging).forEach(([gid, s]) => {
    const base = merged[gid] || { game_id: Number(gid) };
    merged[gid] = {
      ...base,
      enabled:              s.enabled              ?? base.enabled,
      name_override:        s.name_override        ?? base.name_override,
      emoji_override:       s.emoji_override       ?? base.emoji_override,
      reward_override:      s.reward_override      ?? base.reward_override,
      difficulty_override:  s.difficulty_override  ?? base.difficulty_override,
      desc_override:        s.desc_override        ?? base.desc_override,
      entry_fee_skz:        s.entry_fee_skz        ?? base.entry_fee_skz,
      win_prize_skz:        s.win_prize_skz        ?? base.win_prize_skz,
      target_score:         s.target_score         ?? base.target_score,
      duration_seconds:     s.duration_seconds     ?? base.duration_seconds,
      trap_penalty:         s.trap_penalty         ?? base.trap_penalty,
      max_score:            s.max_score            ?? base.max_score,
      solo_win_score:       s.solo_win_score       ?? base.solo_win_score,
      max_plausible_score:  s.max_plausible_score  ?? base.max_plausible_score,
      score_per_hit:        s.score_per_hit        ?? base.score_per_hit,
      score_penalty:        s.score_penalty        ?? base.score_penalty,
      rules_override:       s.rules_override       ?? base.rules_override,
      subtitle_override:    s.subtitle_override    ?? base.subtitle_override,
      win_label_override:   s.win_label_override   ?? base.win_label_override,
      lose_label_override:  s.lose_label_override  ?? base.lose_label_override,
      cta_label_override:   s.cta_label_override   ?? base.cta_label_override,
    };
  });
  return merged;
}

function applyAppColors(cfg) {
  const root = document.documentElement;
  if (cfg.app_bg_color)        { root.style.setProperty('--app-bg', cfg.app_bg_color); document.body.style.background = cfg.app_bg_color; }
  if (cfg.app_primary_color)   root.style.setProperty('--app-primary', cfg.app_primary_color);
  if (cfg.app_secondary_color) root.style.setProperty('--app-secondary', cfg.app_secondary_color);
}

// Solo games that use the fee tier system (no hardcoded entry_fee/prize)
const SOLO_TIER_IDS = new Set([
  1,2,3,4,5,6,7,8,9,10,11,
  56,57,58,59,60,
  76,77,78,79,80,81,82,83,84,85,
  116,117,118,119,120,121,122,123,124,125,
  126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,
  146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,
  161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,
  176,177,178,179,180,181,182,183,184,185,186,187,188,189,190,
  191,192,193,194,195,
  // Solo batch misc
  42,43,45,47,48,49,51,52,54,55,
  71,72,73,74,75,
  106,107,108,109,110,111,112,113,114,115,
]);

function applyOverrides(games, overrides, defaultSoloTier) {
  const defFee   = defaultSoloTier ? Number(defaultSoloTier.entryFee)   : null;
  const defPrize = defaultSoloTier ? Math.round(Number(defaultSoloTier.entryFee) * Number(defaultSoloTier.multiplier)) : null;

  return games
    .map(g => {
      const ov = overrides[g.id];
      const isSoloTier = SOLO_TIER_IDS.has(g.id);
      let entryFee, prize;
      if (ov) {
        entryFee = ov.entry_fee_skz != null ? Number(ov.entry_fee_skz) : (isSoloTier && defFee != null ? defFee : g.entryFee);
        prize    = ov.win_prize_skz != null ? Number(ov.win_prize_skz) : (isSoloTier && defPrize != null ? defPrize : g.prize);
      } else {
        entryFee = isSoloTier && defFee != null ? defFee : g.entryFee;
        prize    = isSoloTier && defPrize != null ? defPrize : g.prize;
      }

      if (!ov && !isSoloTier) return g;
      if (!ov) {
        // Solo tier game with no override — just update fee/prize display
        return { ...g, entryFee, prize, reward: `${prize} SKZ` };
      }

      return {
        ...g,
        name:               ov.name_override       || g.name,
        emoji:              ov.emoji_override      || g.emoji,
        reward:             ov.reward_override     || `${prize} SKZ`,
        difficulty:         ov.difficulty_override || g.difficulty,
        desc:               ov.desc_override       || g.desc,
        entryFee,
        prize,
        targetScore:        ov.target_score        != null ? Number(ov.target_score)        : g.targetScore,
        durationSeconds:    ov.duration_seconds    != null ? Number(ov.duration_seconds)    : g.durationSeconds,
        trapPenalty:        ov.trap_penalty        != null ? Number(ov.trap_penalty)        : g.trapPenalty,
        scorePerHit:        ov.score_per_hit       != null ? Number(ov.score_per_hit)       : g.scorePerHit,
        scorePenalty:       ov.score_penalty       != null ? Number(ov.score_penalty)       : g.scorePenalty,
        maxScore:           ov.max_score           != null ? Number(ov.max_score)           : g.maxScore,
        soloWinScore:       ov.solo_win_score      != null ? Number(ov.solo_win_score)      : g.soloWinScore,
        maxPlausibleScore:  ov.max_plausible_score != null ? Number(ov.max_plausible_score) : g.maxPlausibleScore,
        rulesOverride:      ov.rules_override?.trim() || g.rulesOverride,
        subtitle:           ov.subtitle_override  || g.subtitle,
        winLabel:           ov.win_label_override || g.winLabel,
        loseLabel:          ov.lose_label_override|| g.loseLabel,
        ctaLabel:           ov.cta_label_override || g.ctaLabel,
        _disabled:          ov.enabled === false,
      };
    })
    .filter(g => !g._disabled)
    .map(({ _disabled, ...g }) => g);
}

const useAppStore = create((set, get) => ({
  user: null,
  wallet:        (() => {
    try {
      const cached = localStorage.getItem('skz_wallet');
      if (cached) {
        const w = JSON.parse(cached);
        // Mark as loaded:true so UI renders immediately with cached values — no flicker.
        // refreshBalance() will update in background once the real value arrives.
        if (w?.sc_balance != null) return { ...w, loaded: true };
      }
    } catch { /* ignore */ }
    return { sc_balance: 0, sc_pending: 0, sc_free: 0, trial_active: false, trial_seconds_left: 0, trial_expires_at: null, is_paid: false, loaded: false };
  })(),
  currentPage:   'dashboard',
  gamesFilter:   null,
  language:      localStorage.getItem('lang') || 'en',
  notifications: [],
  selectedGame:  null,
  appConfig:        {},
  defaultSoloTier:  null,
  games:            GAMES,
  gamificationVersion: 0,
  bumpGamification: () => set((s) => ({ gamificationVersion: s.gamificationVersion + 1 })),

  pwaInstallPrompt: null,
  setPwaInstallPrompt: (e) => set({ pwaInstallPrompt: e }),

  setUser:          (user)   => set({ user }),
  setSelectedGame:  (game)   => set({ selectedGame: game }),
  setWallet:        (wallet) => set({ wallet }),
  setCurrentPage:   (page)   => set({ currentPage: page, gamesFilter: null }),
  navigateToGames:  (filter) => set({ currentPage: 'games', gamesFilter: filter }),
  setLanguage: (lang) => { localStorage.setItem('lang', lang); set({ language: lang }); },
  addNotification:    (n)  => set((s) => ({ notifications: [...s.notifications, { ...n, id: Date.now() }] })),
  removeNotification: (id) => set((s) => ({ notifications: s.notifications.filter((n) => n.id !== id) })),

  loadRemoteConfig: async () => {
    const isPreview = new URLSearchParams(window.location.search).get('preview') === '1';
    try {
      const [cfg, liveGames, stagedCfg, stagedGames, soloTiers] = await Promise.all([
        fetchAppConfig().catch(() => ({})),
        fetchGameOverrides().catch(() => ({})),
        isPreview ? fetchStagingConfig().catch(() => []) : Promise.resolve([]),
        isPreview ? fetchStagingGames().catch(() => ({})) : Promise.resolve({}),
        getSoloFeeTiers(null).catch(() => []),
      ]);
      const mergedCfg = { ...cfg };
      if (isPreview) parseConfigRows(stagedCfg, mergedCfg);
      const defaultSoloTier = soloTiers.find(t => t.isDefault) || soloTiers[0] || null;
      const mergedGames = isPreview ? mergeGameOverrides(liveGames, stagedGames) : liveGames;
      set({ appConfig: mergedCfg, games: applyOverrides(GAMES, mergedGames, defaultSoloTier), defaultSoloTier });
      // Apply dynamic colors from manager config as CSS custom properties
      applyAppColors(mergedCfg);
    } catch { /* network failure — keep defaults (GAMES as-is, appConfig: {}) */ }
  },

  refreshBalance: async () => {
    try {
      const b = await getBalance();
      if (!b) {
        set((s) => ({ wallet: { ...s.wallet, loaded: true } }));
        return;
      }
      const w = {
        sc_balance:         Number(b.sc_balance) || 0,
        sc_pending:         Number(b.sc_pending) || 0,
        sc_free:            Number(b.sc_free)    || 0,
        trial_active:       !!b.trial_active,
        trial_seconds_left: Number(b.trial_seconds_left) || 0,
        trial_expires_at:   b.trial_expires_at || null,
        is_paid:            !!b.is_paid,
        loaded:             true,
      };
      set({ wallet: w });
      try { localStorage.setItem('skz_wallet', JSON.stringify(w)); } catch { /* ignore */ }
    } catch {
      set((s) => ({ wallet: { ...s.wallet, loaded: true } }));
    }
  },

  _balanceChannel: null,

  subscribeBalance: () => {
    const { user, _balanceChannel } = get();
    const tgId = user?.telegram_id;
    if (!tgId) return;

    // Always clean up existing channel before creating a new one.
    // Without this, rapid page navigation creates orphaned channels that
    // accumulate indefinitely — at scale each leaked channel holds a
    // Realtime websocket slot on the server.
    if (_balanceChannel) {
      try { supabase.removeChannel(_balanceChannel); } catch { /* ignore */ }
      set({ _balanceChannel: null });
    }

    const channel = supabase
      .channel(`wallet:${tgId}`)
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'user_balances', filter: `telegram_id=eq.${tgId}` },
        (payload) => {
          const row = payload.new || payload.old;
          if (!row) return;
          const exp = row.trial_expires_at ? new Date(row.trial_expires_at).getTime() : 0;
          const isPaid = !!row.is_paid;
          const now = Date.now();
          const secs = Math.max(0, Math.floor((exp - now) / 1000));
          const next = {
            sc_balance:         Number(row.sc_balance) || 0,
            sc_pending:         Number(row.sc_pending) || 0,
            sc_free:            Number(row.sc_free)    || 0,
            trial_active:       !isPaid && exp > now,
            trial_seconds_left: secs,
            trial_expires_at:   row.trial_expires_at || null,
            is_paid:            isPaid,
            loaded:             true,
          };
          // Only update state when numeric values actually changed to prevent
          // unnecessary re-renders (which caused visual flickering).
          const cur = get().wallet;
          if (
            cur.sc_balance === next.sc_balance &&
            cur.sc_pending === next.sc_pending &&
            cur.sc_free    === next.sc_free    &&
            cur.is_paid    === next.is_paid    &&
            cur.trial_active === next.trial_active
          ) return;
          set({ wallet: next });
        }
      )
      .subscribe((status) => {
        // If channel fails to connect (e.g. network error), clean it up so
        // the next call to subscribeBalance starts fresh rather than stacking.
        if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
          supabase.removeChannel(channel);
          set({ _balanceChannel: null });
        }
      });

    set({ _balanceChannel: channel });

    // Safety net: if the user object is cleared (logout) within 60s, remove the
    // channel automatically. This prevents orphaned channels when the React tree
    // unmounts without explicitly calling unsubscribeBalance.
    const leakGuard = setTimeout(() => {
      const { user: currentUser, _balanceChannel: current } = get();
      if (!currentUser?.telegram_id && current === channel) {
        supabase.removeChannel(channel);
        set({ _balanceChannel: null });
      }
    }, 60_000);

    // Store cleanup handle so unsubscribeBalance can clear it
    set({ _balanceLeakGuard: leakGuard });
  },

  _balanceLeakGuard: null,

  unsubscribeBalance: () => {
    const { _balanceChannel, _balanceLeakGuard } = get();
    if (_balanceLeakGuard) {
      clearTimeout(_balanceLeakGuard);
      set({ _balanceLeakGuard: null });
    }
    if (_balanceChannel) {
      supabase.removeChannel(_balanceChannel);
      set({ _balanceChannel: null });
    }
  },
}));

export default useAppStore;
