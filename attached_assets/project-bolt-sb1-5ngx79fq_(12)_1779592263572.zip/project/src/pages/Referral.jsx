import { motion, AnimatePresence } from 'framer-motion';
import { useState, useEffect } from 'react';
import {
  Copy, Check, Users, Gift, Zap, Clock, ArrowRight, Wallet,
  TrendingUp, Crown, Star, Share2, ChevronRight, Trophy,
  User, Flame, Globe, Calendar, ArrowUpRight,
} from 'lucide-react';
import useAppStore from '../store/appStore';
import { t } from '../lib/i18n';
import { triggerHaptic } from '../lib/telegram';
import { getVerifiedSession } from '../lib/telegram';
import { supabase } from '../lib/supabase';
import { transferReferralToWallet } from '../lib/payments';

const container = { animate: { transition: { staggerChildren: 0.07, delayChildren: 0.04 } } };
const item = {
  initial: { opacity: 0, y: 18 },
  animate: { opacity: 1, y: 0, transition: { duration: 0.38, ease: [0.22, 1, 0.36, 1] } },
};

const TIER_ICONS = { user: User, users: Users, zap: Zap, crown: Crown, trophy: Trophy };
const LB_TABS = [
  { id: 'week',  label: 'This Week', icon: Calendar },
  { id: 'month', label: 'This Month', icon: TrendingUp },
  { id: 'all',   label: 'All Time',  icon: Globe },
];

function timeAgo(dateStr) {
  if (!dateStr) return '';
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  if (days < 7) return `${days}d ago`;
  return `${Math.floor(days / 7)}w ago`;
}

function TierBadge({ name, color, mult }) {
  return (
    <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full"
      style={{ background: `${color}18`, border: `1px solid ${color}35` }}>
      <div className="w-1.5 h-1.5 rounded-full" style={{ background: color }} />
      <span className="text-[10px] font-black uppercase tracking-wider" style={{ color }}>{name}</span>
      <span className="text-[9px] font-bold" style={{ color: `${color}90` }}>×{mult}</span>
    </div>
  );
}

export default function Referral() {
  const { user, language, appConfig } = useAppStore();
  const sym = appConfig?.currency_symbol || 'SKZ';

  const [copied, setCopied]           = useState(false);
  const [stats, setStats]             = useState(null);
  const [friends, setFriends]         = useState([]);
  const [tiers, setTiers]             = useState([]);
  const [leaderboard, setLeaderboard] = useState([]);
  const [lbTab, setLbTab]             = useState('week');
  const [lbLoading, setLbLoading]     = useState(false);
  const [loading, setLoading]         = useState(true);
  const [transferBusy, setTransferBusy] = useState(false);
  const [transferMsg, setTransferMsg]   = useState(null);
  const [activeSection, setActiveSection] = useState('overview');

  const botUsername = appConfig?.telegram_bot_username || 'Souqrates_skillz_bot';
  const refLink = `https://t.me/${botUsername}?start=ref_${user?.telegram_id || ''}`;

  const referralEnabled   = appConfig?.referral_enabled !== false;
  const referralRewardText = appConfig?.referral_reward_text || null;
  const referralBonus     = appConfig?.referral_bonus ? Number(appConfig.referral_bonus) : null;
  const referralLifetime  = appConfig?.referral_lifetime ? Number(appConfig.referral_lifetime) : null;

  useEffect(() => {
    let cancelled = false;
    async function load() {
      const sid = getVerifiedSession()?.session_id;
      const [statsRes, friendsRes, tiersRes] = await Promise.all([
        sid ? supabase.rpc('ref_get_my_stats', { p_session_id: sid }) : Promise.resolve({ data: null }),
        sid ? supabase.rpc('ref_get_my_friends', { p_session_id: sid }) : Promise.resolve({ data: null }),
        supabase.rpc('ref_get_tiers'),
      ]);
      if (cancelled) return;
      if (statsRes.data?.ok) setStats(statsRes.data);
      if (friendsRes.data?.ok && Array.isArray(friendsRes.data.friends)) setFriends(friendsRes.data.friends);
      if (Array.isArray(tiersRes.data)) setTiers(tiersRes.data);
      setLoading(false);
    }
    load();
    return () => { cancelled = true; };
  }, [user?.telegram_id]);

  useEffect(() => {
    let cancelled = false;
    async function loadLb() {
      setLbLoading(true);
      const { data } = await supabase.rpc('ref_get_affiliate_leaderboard', { p_period: lbTab, p_limit: 20 });
      if (!cancelled) {
        setLeaderboard(Array.isArray(data?.items) ? data.items : []);
        setLbLoading(false);
      }
    }
    loadLb();
    return () => { cancelled = true; };
  }, [lbTab]);

  const copy = async () => {
    try { await navigator.clipboard.writeText(refLink); } catch { /* ignore */ }
    triggerHaptic('success');
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const shareNative = async () => {
    const text = `🎮 Join me on SkillGames and start winning!\n\nI've earned ${Number(stats?.total_earned || 0).toLocaleString()} ${sym} from referrals.\n\nJoin here 👇`;
    triggerHaptic('medium');
    if (navigator.share) {
      try { await navigator.share({ text, url: refLink }); return; } catch { /* fall through */ }
    }
    copy();
  };

  const handleTransfer = async () => {
    if (transferBusy || !stats?.referral_balance || stats.referral_balance <= 0) return;
    setTransferBusy(true);
    setTransferMsg(null);
    try {
      const res = await transferReferralToWallet();
      if (res?.ok) {
        triggerHaptic('success');
        setTransferMsg({ type: 'success', text: `${Number(res.transferred).toLocaleString()} ${sym} transferred!` });
        setStats(s => s ? { ...s, referral_balance: 0 } : s);
      } else {
        setTransferMsg({ type: 'error', text: res?.error || 'Transfer failed' });
      }
    } catch (e) {
      setTransferMsg({ type: 'error', text: 'Transfer failed' });
    }
    setTransferBusy(false);
  };

  const tierName    = stats?.tier_name  || 'Starter';
  const tierColor   = stats?.tier_color || '#94a3b8';
  const tierMult    = stats?.tier_mult  || 1.0;
  const nextTierAt  = stats?.next_tier_at;
  const totalInvites = stats?.total_invites || 0;
  const paidInvites  = stats?.paid_invites  || 0;
  const tierPct     = nextTierAt ? Math.min(100, Math.round((paidInvites / nextTierAt) * 100)) : 100;

  const currentTierIdx = tiers.findIndex(t => t.name === tierName);

  const SECTIONS = [
    { id: 'overview',    label: 'Overview'    },
    { id: 'friends',     label: 'Friends'     },
    { id: 'leaderboard', label: 'Top Earners' },
    { id: 'tiers',       label: 'Tiers'       },
  ];

  return (
    <motion.div
      className="px-4 pt-5 pb-8 space-y-4 relative z-10"
      variants={container}
      initial="initial"
      animate="animate"
    >
      {/* Header */}
      <motion.div variants={item} className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <Gift size={17} style={{ color: '#10b981', filter: 'drop-shadow(0 0 8px rgba(16,185,129,0.9))' }} />
          <h1 className="font-orbitron text-base font-black text-white tracking-widest">Invite &amp; Earn</h1>
        </div>
        {stats && <TierBadge name={tierName} color={tierColor} mult={tierMult} />}
      </motion.div>

      {/* Referral disabled notice */}
      {!referralEnabled && (
        <motion.div variants={item} style={{ padding: '20px 16px', borderRadius: 16, background: 'rgba(239,68,68,0.07)', border: '1px solid rgba(239,68,68,0.25)', textAlign: 'center' }}>
          <p style={{ fontSize: 13, color: 'rgba(239,68,68,0.9)', fontWeight: 700 }}>Referral Program Temporarily Disabled</p>
          <p style={{ fontSize: 11, color: 'rgba(148,163,184,0.6)', marginTop: 6 }}>Check back soon for referral rewards!</p>
        </motion.div>
      )}

      {/* Admin reward text */}
      {referralEnabled && referralRewardText && (
        <motion.div variants={item} style={{ padding: '10px 14px', borderRadius: 12, background: 'rgba(16,185,129,0.07)', border: '1px solid rgba(16,185,129,0.2)' }}>
          <p style={{ fontSize: 12, color: 'rgba(16,185,129,0.9)', lineHeight: 1.5 }}>{referralRewardText}</p>
        </motion.div>
      )}

      {/* Referral link card — hidden when referral program is disabled */}
      {referralEnabled && <motion.div variants={item} className="glass-hero rounded-3xl p-5 relative overflow-hidden">
        <div className="absolute -top-10 -right-10 w-44 h-44 rounded-full blur-3xl pointer-events-none"
          style={{ background: 'rgba(16,185,129,0.14)' }} />
        <div className="absolute -bottom-8 -left-6 w-32 h-32 rounded-full blur-3xl pointer-events-none"
          style={{ background: 'rgba(34,211,238,0.08)' }} />

        <p className="text-[9px] font-black uppercase tracking-widest mb-3 relative z-10"
          style={{ color: 'rgba(148,163,184,0.55)' }}>
          Your Referral Link
        </p>

        <div className="rounded-xl px-4 py-3 mb-4 relative z-10 select-all"
          style={{
            background: 'rgba(10,7,20,0.60)',
            border: '1px solid rgba(16,185,129,0.20)',
          }}>
          <p className="text-[11px] font-mono leading-relaxed break-all" style={{ color: '#34d399' }}>
            {refLink}
          </p>
        </div>

        <div className="grid grid-cols-2 gap-2.5 relative z-10">
          <motion.button
            onClick={copy}
            whileTap={{ scale: 0.96 }}
            className="flex items-center justify-center gap-2 py-3 rounded-xl font-black text-[11px]"
            style={copied ? {
              background: 'rgba(16,185,129,0.10)',
              border: '1px solid rgba(16,185,129,0.28)',
              color: '#34d399',
            } : {
              background: 'linear-gradient(135deg,#047857,#10b981)',
              border: '1px solid rgba(16,185,129,0.35)',
              color: '#fff',
              boxShadow: '0 4px 18px rgba(16,185,129,0.35)',
              fontFamily: 'Orbitron, sans-serif',
              letterSpacing: '0.08em',
            }}
          >
            {copied ? <><Check size={14} />Copied!</> : <><Copy size={14} />Copy Link</>}
          </motion.button>

          <motion.button
            onClick={shareNative}
            whileTap={{ scale: 0.96 }}
            className="flex items-center justify-center gap-2 py-3 rounded-xl"
            style={{
              background: 'rgba(34,211,238,0.08)',
              border: '1px solid rgba(34,211,238,0.25)',
            }}
          >
            <Share2 size={14} style={{ color: '#22d3ee' }} />
            <span className="text-[11px] font-black uppercase tracking-wider" style={{ color: '#22d3ee' }}>
              Share
            </span>
          </motion.button>
        </div>
      </motion.div>}

      {/* Section tabs */}
      <motion.div variants={item} className="flex gap-2 overflow-x-auto pb-1" style={{ scrollbarWidth: 'none' }}>
        {SECTIONS.map(s => {
          const active = activeSection === s.id;
          return (
            <motion.button
              key={s.id}
              whileTap={{ scale: 0.94 }}
              onClick={() => setActiveSection(s.id)}
              className="flex-shrink-0 px-3.5 py-2 rounded-xl text-[10px] font-black uppercase tracking-wider"
              style={{
                background: active ? 'rgba(16,185,129,0.12)' : 'rgba(255,255,255,0.04)',
                border: `1px solid ${active ? 'rgba(16,185,129,0.35)' : 'rgba(255,255,255,0.07)'}`,
                color: active ? '#10b981' : 'rgba(148,163,184,0.6)',
                transition: 'all 0.15s',
              }}
            >
              {s.label}
            </motion.button>
          );
        })}
      </motion.div>

      {/* ── OVERVIEW ── */}
      <AnimatePresence mode="wait">
        {activeSection === 'overview' && (
          <motion.div
            key="overview"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.22 }}
            className="space-y-4"
          >
            {/* Stats 2×2 grid */}
            <div className="grid grid-cols-2 gap-2.5">
              {[
                { label: 'Total Invites',    value: totalInvites,                                                                         icon: Users,       color: '#22d3ee' },
                { label: 'Active Friends',  value: stats?.active_refs || 0,                                                                  icon: Zap,         color: '#10b981' },
                { label: 'Direct (L1)',     value: `${Number(stats?.l1_earned || 0).toLocaleString()} ${sym}`,                               icon: Gift,        color: '#f59e0b' },
                { label: 'Chain (L2+)',     value: `${Number(stats?.l2_earned || 0).toLocaleString()} ${sym}`,                               icon: TrendingUp,  color: '#38bdf8' },
              ].map(({ label, value, icon: Icon, color }) => (
                <div key={label} className="rounded-2xl p-3.5 relative overflow-hidden"
                  style={{ background: `${color}0d`, border: `1px solid ${color}25` }}>
                  <div className="absolute -top-4 -right-4 w-16 h-16 rounded-full blur-2xl pointer-events-none"
                    style={{ background: `${color}18` }} />
                  <Icon size={16} className="mb-2 relative z-10" style={{ color, filter: `drop-shadow(0 0 5px ${color})` }} />
                  <p className="font-orbitron text-lg font-black relative z-10 leading-none" style={{ color }}>{value}</p>
                  <p className="text-[9px] font-bold uppercase tracking-wide mt-1.5 relative z-10"
                    style={{ color: 'rgba(148,163,184,0.55)' }}>{label}</p>
                </div>
              ))}
            </div>

            {/* This week highlight */}
            {stats?.this_week > 0 && (
              <div className="rounded-2xl p-4 flex items-center gap-3"
                style={{ background: 'rgba(245,158,11,0.08)', border: '1px solid rgba(245,158,11,0.22)' }}>
                <Flame size={18} style={{ color: '#f59e0b', filter: 'drop-shadow(0 0 6px rgba(245,158,11,0.8))' }} />
                <div>
                  <p className="text-[10px] font-black uppercase tracking-widest" style={{ color: 'rgba(148,163,184,0.7)' }}>This Week</p>
                  <p className="font-orbitron text-lg font-black shimmer-gold leading-tight">
                    +{Number(stats.this_week).toLocaleString()} {sym}
                  </p>
                </div>
              </div>
            )}

            {/* Referral Balance + Transfer */}
            <div className="glass-card rounded-2xl p-4 relative overflow-hidden"
              style={{ border: '1px solid rgba(16,185,129,0.22)' }}>
              <div className="absolute -top-8 -right-8 w-32 h-32 rounded-full blur-3xl pointer-events-none"
                style={{ background: 'rgba(16,185,129,0.10)' }} />
              <div className="flex items-center gap-1.5 mb-3 relative z-10">
                <Wallet size={11} style={{ color: '#10b981' }} />
                <p className="text-[9px] font-black uppercase tracking-widest" style={{ color: 'rgba(148,163,184,0.78)' }}>
                  Referral Balance
                </p>
              </div>
              <div className="flex items-center justify-between relative z-10">
                <div>
                  <div className="flex items-baseline gap-1.5">
                    <p className="font-orbitron text-2xl font-black text-white">
                      {Number(stats?.referral_balance || 0).toLocaleString()}
                    </p>
                    <p className="font-orbitron text-xs font-black" style={{ color: '#10b981' }}>{sym}</p>
                  </div>
                  <p className="text-[10px] mt-1" style={{ color: 'rgba(148,163,184,0.6)' }}>
                    From commissions — withdraw anytime
                  </p>
                </div>
                <motion.button
                  whileTap={{ scale: 0.95 }}
                  onClick={handleTransfer}
                  disabled={transferBusy || !stats?.referral_balance || stats.referral_balance <= 0}
                  className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl flex-shrink-0"
                  style={(stats?.referral_balance || 0) > 0 && !transferBusy ? {
                    background: 'linear-gradient(135deg,#047857,#10b981)',
                    border: '1px solid rgba(16,185,129,0.35)',
                    color: '#fff',
                    boxShadow: '0 0 18px rgba(16,185,129,0.3)',
                    fontFamily: 'Orbitron, sans-serif',
                    letterSpacing: '0.06em',
                    fontSize: '10px',
                    fontWeight: 900,
                  } : {
                    background: 'rgba(16,185,129,0.06)',
                    border: '1px solid rgba(16,185,129,0.12)',
                    color: 'rgba(16,185,129,0.35)',
                    fontSize: '10px',
                    fontWeight: 900,
                    cursor: 'default',
                  }}
                >
                  <ArrowRight size={12} />
                  {transferBusy ? '...' : 'Transfer'}
                </motion.button>
              </div>
              {transferMsg && (
                <p className="text-[11px] mt-2.5 relative z-10 font-semibold"
                  style={{ color: transferMsg.type === 'success' ? '#34d399' : '#fb7185' }}>
                  {transferMsg.text}
                </p>
              )}
            </div>

            {/* Tier progress */}
            <div className="rounded-2xl p-4 relative overflow-hidden"
              style={{ background: `${tierColor}0d`, border: `1px solid ${tierColor}25` }}>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl flex items-center justify-center"
                    style={{ background: `${tierColor}20`, border: `1px solid ${tierColor}40` }}>
                    <Crown size={14} style={{ color: tierColor }} />
                  </div>
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-widest" style={{ color: `${tierColor}cc` }}>
                      {tierName} Affiliate
                    </p>
                    <p className="text-[9px] font-semibold" style={{ color: 'rgba(148,163,184,0.6)' }}>
                      {paidInvites} paid referrals · ×{tierMult} commission
                    </p>
                  </div>
                </div>
                {nextTierAt && (
                  <p className="text-[9px] font-black" style={{ color: 'rgba(148,163,184,0.55)' }}>
                    {nextTierAt - paidInvites} to next
                  </p>
                )}
              </div>
              <div className="h-1.5 rounded-full overflow-hidden"
                style={{ background: 'rgba(255,255,255,0.06)' }}>
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${tierPct}%` }}
                  transition={{ duration: 0.7, ease: 'easeOut', delay: 0.3 }}
                  style={{
                    height: '100%',
                    background: `linear-gradient(90deg, ${tierColor}90, ${tierColor})`,
                    boxShadow: `0 0 8px ${tierColor}60`,
                    borderRadius: 9999,
                  }}
                />
              </div>
            </div>

            {/* How it works */}
            <div className="glass-card rounded-2xl p-4">
              <p className="text-[9px] font-black uppercase tracking-widest mb-4"
                style={{ color: 'rgba(148,163,184,0.55)' }}>How It Works</p>
              <div className="space-y-3">
                {[
                  { n: '01', text: 'Share your referral link — works in Telegram, WhatsApp, anywhere' },
                  { n: '02', text: `Friend joins and plays — you earn ${referralBonus != null ? referralBonus : 5}% of every prize they win (L1)` },
                  { n: '03', text: "Your friend invites someone else — you earn a chain commission of their L1 amount (L2)" },
                  { n: '04', text: 'The chain continues — each level earns a percentage of the level below it, forever' },
                  { n: '05', text: 'Reach higher tiers for bigger L1 multipliers — the more paid referrals, the higher your rate' },
                ].map(({ n, text }) => (
                  <div key={n} className="flex items-start gap-3">
                    <div className="w-7 h-7 rounded-xl flex items-center justify-center flex-shrink-0 mt-0.5"
                      style={{ background: 'rgba(16,185,129,0.12)', border: '1px solid rgba(16,185,129,0.25)' }}>
                      <span className="font-orbitron text-[9px] font-black" style={{ color: '#10b981' }}>{n}</span>
                    </div>
                    <p className="text-sm font-medium leading-relaxed" style={{ color: 'rgba(203,195,215,0.85)' }}>{text}</p>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        )}

        {/* ── FRIENDS ── */}
        {activeSection === 'friends' && (
          <motion.div
            key="friends"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.22 }}
          >
            <div className="glass-card rounded-2xl overflow-hidden">
              {loading ? (
                <div className="p-4 space-y-2">
                  {[...Array(5)].map((_, i) => <div key={i} className="skeleton h-14 rounded-xl" />)}
                </div>
              ) : friends.length === 0 ? (
                <div className="px-4 py-10 text-center">
                  <Users size={32} color="rgba(148,163,184,0.2)" style={{ margin: '0 auto 12px' }} />
                  <p className="text-sm font-bold" style={{ color: 'rgba(148,163,184,0.5)' }}>
                    No referrals yet
                  </p>
                  <p className="text-[11px] mt-1 font-medium" style={{ color: 'rgba(148,163,184,0.35)' }}>
                    Share your link to start earning commissions
                  </p>
                </div>
              ) : friends.map((f, i) => (
                <div key={f.telegram_id || i}
                  className={`flex items-center gap-3 px-4 py-3.5 ${i < friends.length - 1 ? 'border-b' : ''}`}
                  style={{ borderColor: 'rgba(255,255,255,0.05)' }}>
                  <div className="w-9 h-9 rounded-xl flex items-center justify-center text-xs font-black flex-shrink-0"
                    style={{ background: 'rgba(16,185,129,0.10)', border: '1px solid rgba(16,185,129,0.18)', color: '#34d399' }}>
                    {(f.name || 'P').charAt(0).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-sm text-white truncate">{f.name || 'Player'}</p>
                    <p className="text-[10px] font-medium flex items-center gap-1" style={{ color: 'rgba(148,163,184,0.6)' }}>
                      <Clock size={8} />
                      {timeAgo(f.joined_at)}
                    </p>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p className="font-black text-sm" style={{ color: '#f59e0b' }}>
                      +{Number(f.total_bonus || 0).toLocaleString()} {sym}
                    </p>
                    <span className="text-[9px] font-black px-2 py-0.5 rounded-full uppercase tracking-wide"
                      style={f.status === 'Active'
                        ? { background: 'rgba(16,185,129,0.12)', border: '1px solid rgba(16,185,129,0.22)', color: '#34d399' }
                        : f.status === 'Inactive'
                          ? { background: 'rgba(148,163,184,0.08)', border: '1px solid rgba(148,163,184,0.15)', color: 'rgba(148,163,184,0.6)' }
                          : { background: 'rgba(245,158,11,0.12)', border: '1px solid rgba(245,158,11,0.22)', color: '#fbbf24' }
                      }>
                      {f.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {/* ── LEADERBOARD ── */}
        {activeSection === 'leaderboard' && (
          <motion.div
            key="leaderboard"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.22 }}
            className="space-y-3"
          >
            {/* Period tabs */}
            <div className="flex gap-2">
              {LB_TABS.map(({ id, label, icon: Icon }) => {
                const active = lbTab === id;
                return (
                  <motion.button key={id} whileTap={{ scale: 0.94 }}
                    onClick={() => setLbTab(id)}
                    className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl"
                    style={{
                      background: active ? 'rgba(245,158,11,0.12)' : 'rgba(255,255,255,0.04)',
                      border: `1px solid ${active ? 'rgba(245,158,11,0.35)' : 'rgba(255,255,255,0.07)'}`,
                      transition: 'all 0.15s',
                    }}>
                    <Icon size={11} style={{ color: active ? '#f59e0b' : 'rgba(148,163,184,0.5)' }} />
                    <span className="text-[9px] font-black uppercase tracking-wider"
                      style={{ color: active ? '#f59e0b' : 'rgba(148,163,184,0.6)' }}>{label}</span>
                  </motion.button>
                );
              })}
            </div>

            <div className="glass-card rounded-2xl overflow-hidden">
              {lbLoading ? (
                <div className="p-4 space-y-2">
                  {[...Array(8)].map((_, i) => <div key={i} className="skeleton h-12 rounded-xl" />)}
                </div>
              ) : leaderboard.length === 0 ? (
                <div className="px-4 py-10 text-center">
                  <Trophy size={28} color="rgba(148,163,184,0.2)" style={{ margin: '0 auto 10px' }} />
                  <p className="text-sm font-bold" style={{ color: 'rgba(148,163,184,0.5)' }}>No data yet for this period</p>
                </div>
              ) : leaderboard.map((row, i) => {
                const isYou = user?.telegram_id && Number(row.telegram_id) === Number(user.telegram_id);
                const rankColor = i === 0 ? '#f59e0b' : i === 1 ? '#94a3b8' : i === 2 ? '#f97316' : 'rgba(148,163,184,0.6)';
                return (
                  <div key={row.telegram_id || i}
                    className={`flex items-center gap-3 px-4 py-3.5 ${i < leaderboard.length - 1 ? 'border-b' : ''}`}
                    style={{
                      borderColor: 'rgba(255,255,255,0.05)',
                      background: isYou ? 'rgba(16,185,129,0.06)' : 'transparent',
                    }}>
                    <span className="w-6 text-center font-orbitron font-black text-sm flex-shrink-0"
                      style={{ color: rankColor }}>#{i + 1}</span>
                    <div className="w-8 h-8 rounded-xl flex items-center justify-center text-xs font-black flex-shrink-0"
                      style={isYou
                        ? { background: 'rgba(16,185,129,0.18)', border: '1px solid rgba(16,185,129,0.3)', color: '#34d399' }
                        : { background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)', color: '#94a3b8' }}>
                      {(row.anon_name || row.name || 'P').charAt(0).toUpperCase()}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-sm truncate" style={{ color: isYou ? '#34d399' : '#e2e8f0' }}>
                        {isYou ? 'You' : (row.anon_name || row.name || 'Player')}
                      </p>
                      <p className="text-[10px]" style={{ color: 'rgba(148,163,184,0.6)' }}>
                        {row.referral_count} referrals
                      </p>
                    </div>
                    <p className="font-orbitron font-black text-sm flex-shrink-0" style={{ color: '#f59e0b' }}>
                      {Number(row.total_earned || 0).toLocaleString()} {sym}
                    </p>
                  </div>
                );
              })}
            </div>

            <div className="rounded-2xl p-3.5 flex items-center gap-2.5"
              style={{ background: 'rgba(34,211,238,0.05)', border: '1px solid rgba(34,211,238,0.15)' }}>
              <ArrowUpRight size={14} style={{ color: '#22d3ee', flexShrink: 0 }} />
              <p className="text-[10px] font-semibold" style={{ color: 'rgba(148,163,184,0.75)' }}>
                Invite more friends to climb the leaderboard and unlock bigger commission tiers.
              </p>
            </div>
          </motion.div>
        )}

        {/* ── TIERS ── */}
        {activeSection === 'tiers' && (
          <motion.div
            key="tiers"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.22 }}
            className="space-y-3"
          >
            <div className="rounded-2xl p-4 relative overflow-hidden"
              style={{ background: 'rgba(34,211,238,0.05)', border: '1px solid rgba(34,211,238,0.15)' }}>
              <p className="text-[10px] font-semibold" style={{ color: 'rgba(148,163,184,0.75)' }}>
                The more friends you invite, the higher your tier — and the more you earn per referral win.
                The more friends you invite (who play with real money), the higher your tier and your L1 commission rate. Every level above L1 earns a chain percentage of the level below's commission — the chain cascades indefinitely.
              </p>
            </div>

            {(tiers.length > 0 ? tiers : [
              { name: 'Starter', min_referrals: 0,   commission_multiplier: 1.0, color: '#94a3b8', description: '5% commission on every referral win' },
              { name: 'Creator', min_referrals: 10,  commission_multiplier: 1.4, color: '#22d3ee', description: '7% — unlock at 10 referrals' },
              { name: 'Pro',     min_referrals: 50,  commission_multiplier: 1.8, color: '#f59e0b', description: '9% — unlock at 50 referrals' },
              { name: 'Elite',   min_referrals: 150, commission_multiplier: 2.2, color: '#f97316', description: '11% — unlock at 150 referrals' },
              { name: 'Legend',  min_referrals: 500, commission_multiplier: 2.6, color: '#fbbf24', description: '13% — unlock at 500 referrals' },
            ]).map((tier, i) => {
              const isCurrentTier = tier.name === tierName;
              const isUnlocked = paidInvites >= tier.min_referrals;
              const TierIcon = TIER_ICONS[tier.icon] || Crown;
              return (
                <div key={tier.name}
                  className="rounded-2xl p-4 relative overflow-hidden"
                  style={{
                    background: isCurrentTier
                      ? `${tier.color}14`
                      : isUnlocked ? `${tier.color}08` : 'rgba(255,255,255,0.02)',
                    border: `1px solid ${isCurrentTier ? tier.color + '45' : isUnlocked ? tier.color + '25' : 'rgba(255,255,255,0.06)'}`,
                    boxShadow: isCurrentTier ? `0 0 24px ${tier.color}15` : 'none',
                  }}>
                  {isCurrentTier && (
                    <div className="absolute -top-6 -right-6 w-24 h-24 rounded-full blur-2xl pointer-events-none"
                      style={{ background: `${tier.color}20` }} />
                  )}
                  <div className="flex items-center gap-3 relative z-10">
                    <div className="w-11 h-11 rounded-2xl flex items-center justify-center flex-shrink-0"
                      style={{
                        background: isUnlocked ? `${tier.color}20` : 'rgba(255,255,255,0.04)',
                        border: `1px solid ${isUnlocked ? tier.color + '45' : 'rgba(255,255,255,0.07)'}`,
                        boxShadow: isCurrentTier ? `0 0 14px ${tier.color}40` : 'none',
                      }}>
                      <Crown size={18} style={{
                        color: isUnlocked ? tier.color : 'rgba(148,163,184,0.3)',
                        filter: isCurrentTier ? `drop-shadow(0 0 6px ${tier.color})` : 'none',
                      }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="font-orbitron text-sm font-black" style={{ color: isUnlocked ? tier.color : 'rgba(148,163,184,0.4)' }}>
                          {tier.name}
                        </p>
                        {isCurrentTier && (
                          <span className="text-[8px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider"
                            style={{ background: `${tier.color}20`, border: `1px solid ${tier.color}40`, color: tier.color }}>
                            Current
                          </span>
                        )}
                      </div>
                      <p className="text-[10px] font-medium mt-0.5" style={{ color: isUnlocked ? 'rgba(148,163,184,0.75)' : 'rgba(148,163,184,0.3)' }}>
                        {tier.description}
                      </p>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <p className="font-orbitron text-base font-black" style={{ color: isUnlocked ? tier.color : 'rgba(148,163,184,0.3)' }}>
                        ×{tier.commission_multiplier}
                      </p>
                      {tier.min_referrals > 0 && (
                        <p className="text-[9px] font-bold mt-0.5" style={{ color: 'rgba(148,163,184,0.4)' }}>
                          {tier.min_referrals}+ refs
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}

            <div className="rounded-2xl p-4"
              style={{ background: 'rgba(16,185,129,0.06)', border: '1px solid rgba(16,185,129,0.18)' }}>
              <p className="text-[10px] font-black uppercase tracking-widest mb-2" style={{ color: 'rgba(148,163,184,0.6)' }}>
                Infinite Chain Commission
              </p>
              <p className="text-sm font-semibold mb-3" style={{ color: 'rgba(203,195,215,0.85)' }}>
                Your network compounds infinitely. Each level above L1 earns a chain percentage of the level below's commission — the chain keeps paying as long as anyone in it wins.
              </p>
              <div className="space-y-1.5 font-mono text-[10px]" style={{ color: 'rgba(148,163,184,0.7)' }}>
                <p><span style={{ color: '#f59e0b' }}>L1</span> → {referralBonus != null ? referralBonus : 5}% of winner's prize</p>
                <p><span style={{ color: '#38bdf8' }}>L2</span> → chain% of L1's commission</p>
                <p><span style={{ color: '#a78bfa' }}>L3</span> → chain% of L2's commission</p>
                <p style={{ color: 'rgba(148,163,184,0.4)' }}>L4, L5 ... → keeps cascading up the chain</p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
