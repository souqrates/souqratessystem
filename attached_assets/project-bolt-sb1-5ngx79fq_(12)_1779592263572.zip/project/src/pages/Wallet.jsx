import { motion, AnimatePresence } from 'framer-motion';
import { useState, useEffect, useCallback, useRef } from 'react';
import { ArrowUpRight, ArrowDownLeft, CircleAlert as AlertCircle, CircleCheck as CheckCircle2, Wallet as WalletIcon, Send, Clock, ExternalLink, Copy, Coins, Download, Gift, X, RefreshCw, ShieldCheck, TriangleAlert as AlertTriangle, Zap, ChevronRight, Sparkles } from 'lucide-react';
import useAppStore from '../store/appStore';
import { t } from '../lib/i18n';
import { triggerHaptic, showTelegramConfirm } from '../lib/telegram';
import {
  getBalance, listLedger, getEconomySettings,
  createTonDepositIntent, requestTonWithdrawal, convertTrialToPaid,
  cancelWithdrawal, getPendingWithdrawals, checkDepositIntent,
  testnetSimulateWithdrawal, testnetGetSimulatedTxs,
} from '../lib/payments';
import { supabase } from '../lib/supabase';

const container = { animate: { transition: { staggerChildren: 0.08, delayChildren: 0.04 } } };
const item = {
  initial: { opacity: 0, y: 18 },
  animate: { opacity: 1, y: 0, transition: { duration: 0.38, ease: [0.22, 1, 0.36, 1] } },
};

const TON_PRESETS = [1, 2, 5, 10, 25];

const TON_ADDRESS_RE = /^(UQ|EQ)[A-Za-z0-9_-]{46}$|^0:[0-9a-fA-F]{64}$/;

function buildTonTransferLink(address, amountTon, memo) {
  if (!address) return '';
  const nano = Math.round(Number(amountTon) * 1_000_000_000);
  const params = new URLSearchParams();
  if (nano > 0) params.set('amount', String(nano));
  if (memo) params.set('text', memo);
  const qs = params.toString();
  return `ton://transfer/${address}${qs ? '?' + qs : ''}`;
}

function num(v, def = 0) { const n = Number(v); return Number.isFinite(n) ? n : def; }

function formatRelativeTime(dateStr) {
  if (!dateStr) return '';
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return new Date(dateStr).toLocaleDateString();
}

function WithdrawalStatusBadge({ status }) {
  const cfg = {
    pending:    { color: '#f59e0b', bg: 'rgba(245,158,11,0.12)',  border: 'rgba(245,158,11,0.3)',  label: 'Pending' },
    approved:   { color: '#22d3ee', bg: 'rgba(34,211,238,0.10)',  border: 'rgba(34,211,238,0.3)',  label: 'Approved' },
    processing: { color: '#c084fc', bg: 'rgba(192,132,252,0.10)', border: 'rgba(192,132,252,0.3)', label: 'Processing' },
    sent:       { color: '#10b981', bg: 'rgba(16,185,129,0.10)',  border: 'rgba(16,185,129,0.3)',  label: 'Sent' },
    confirmed:  { color: '#10b981', bg: 'rgba(16,185,129,0.12)',  border: 'rgba(16,185,129,0.35)', label: 'Confirmed' },
  };
  const s = cfg[status] || { color: 'rgba(148,163,184,0.7)', bg: 'rgba(148,163,184,0.06)', border: 'rgba(148,163,184,0.2)', label: status };
  return (
    <span className="text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full"
      style={{ color: s.color, background: s.bg, border: `1px solid ${s.border}` }}>
      {s.label}
    </span>
  );
}

export default function Wallet() {
  const { language, appConfig } = useAppStore();
  const [tab, setTab] = useState('buy');
  const [tonIntent, setTonIntent] = useState(null);
  const [copiedField, setCopiedField] = useState('');
  const [balance, setBalance] = useState(null);
  const [econ, setEcon] = useState({});
  const [ledger, setLedger] = useState([]);
  const [pendingWithdrawals, setPendingWithdrawals] = useState([]);
  const [busy, setBusy] = useState(false);
  const [cancellingId, setCancellingId] = useState(null);
  const [notice, setNotice] = useState(null);
  const [depositCurrency, setDepositCurrency] = useState('TON');

  const [tonAmount, setTonAmount] = useState(2);
  const [scAmount, setScAmount] = useState('');
  const [tonAddress, setTonAddress] = useState('');
  const [addressError, setAddressError] = useState('');
  const [intentConfirmed, setIntentConfirmed] = useState(false);
  const [intentCredits, setIntentCredits] = useState(0);
  const pollRef = useRef(null);

  // Testnet state
  const [testnetResult, setTestnetResult] = useState(null);
  const [testnetTxs, setTestnetTxs] = useState([]);

  const isTestnet = econ.testnet_mode === 'true' || appConfig?.testnet_mode === 'true';
  const testnetWallet = appConfig?.testnet_wallet_address || 'EQDtestNetHotWallet7f3k9mX2pQr4vL8nB5cJ1dZ6wY0uI';
  const testnetExplorer = appConfig?.testnet_explorer_url || 'https://testnet.tonscan.org/tx/';

  const sym = econ.currency_symbol || 'SKZ';
  const scPerTon = num(econ.sc_per_ton, 500);
  const scPerUsdt = num(econ.sc_per_usdt, 500);
  const usdtDepositEnabled = econ.usdt_deposit_enabled !== 'false';
  const tonPerScWithdraw = num(econ.ton_per_sc_withdraw, 0.0018);
  const minWithdrawSc = num(econ.withdraw_min_sc, 500);
  const feePercent = num(econ.withdraw_fee_percent, 2);
  const feeMin = num(econ.withdraw_fee_min_sc, 50);
  const tonkeeperPromoEnabled = econ.tonkeeper_promo_enabled !== 'false';
  const tonkeeperUrl = econ.tonkeeper_promo_url || 'https://tonkeeper.com';
  const tonEta = num(econ.ton_deposit_eta_minutes, 2);

  const activeCurrencyRate = depositCurrency === 'USDT' ? scPerUsdt : scPerTon;
  const activeCurrencyLabel = depositCurrency === 'USDT' ? 'USDT' : 'TON';

  const walletEnabled = econ.telegram_wallet_enabled !== 'false';
  const walletHint    = econ.telegram_wallet_hint    || 'Buy TON or USDT with your Visa card — no crypto wallet needed';
  const walletStep1   = econ.wallet_deposit_step1    || 'Open @wallet and buy TON with your Visa card';
  const walletStep2   = econ.wallet_deposit_step2    || 'Tap Send in @wallet, paste the address & memo below';
  const walletStep3   = econ.wallet_deposit_step3    || 'Your SKZ balance tops up automatically within ~2 minutes';
  // wallet_deposit_note from manager_config — shown as a top-level notice in the deposit tab
  const depositNote   = appConfig?.wallet_deposit_note || null;

  const refresh = useCallback(async () => {
    try {
      const [b, e, l, pw, ttxs] = await Promise.all([
        getBalance().catch(() => null),
        getEconomySettings().catch(() => ({})),
        listLedger({ limit: 20 }).catch(() => []),
        getPendingWithdrawals().catch(() => ({ requests: [] })),
        testnetGetSimulatedTxs().catch(() => ({ txs: [] })),
      ]);
      setBalance(b);
      setEcon(e);
      setLedger(l);
      setPendingWithdrawals(pw?.requests || []);
      setTestnetTxs(ttxs?.txs || []);
    } catch { /* ignore */ }
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  // Subscribe to deposit intent via Realtime instead of polling every 15s.
  // Polling 100K concurrent depositors = 6,666 DB queries/sec — Realtime is push-based.
  useEffect(() => {
    if (!tonIntent?.intentId || intentConfirmed) return;

    const channel = supabase
      .channel(`deposit_intent:${tonIntent.intentId}`)
      .on('postgres_changes', {
        event: 'UPDATE',
        schema: 'public',
        table: 'ton_deposit_intents',
        filter: `id=eq.${tonIntent.intentId}`,
      }, (payload) => {
        const row = payload.new;
        if (row?.status === 'matched') {
          setIntentConfirmed(true);
          setIntentCredits(row.sc_credited ?? tonIntent.expectedSc ?? 0);
          triggerHaptic('success');
          setTimeout(refresh, 400);
        } else if (row?.status === 'expired') {
          setTonIntent(null);
          setIntentConfirmed(false);
          setNotice({ type: 'warning', text: 'Deposit window expired. Please create a new request.' });
        }
      })
      .subscribe();

    // Fallback: one single check 30s after intent creation in case Realtime misses the event
    pollRef.current = setTimeout(async () => {
      const row = await checkDepositIntent(tonIntent.intentId).catch(() => null);
      if (row?.status === 'matched') {
        setIntentConfirmed(true);
        setIntentCredits(row.sc_credited ?? tonIntent.expectedSc ?? 0);
        triggerHaptic('success');
        setTimeout(refresh, 400);
      }
    }, 30000);

    return () => {
      supabase.removeChannel(channel);
      clearTimeout(pollRef.current);
    };
  }, [tonIntent?.intentId, intentConfirmed, refresh]);

  const scBalance       = num(balance?.sc_balance, 0);
  const scPending       = num(balance?.sc_pending, 0);
  const lifetimeWonUsd      = num(balance?.total_won_usd, 0);
  const lifetimeDepositUsd  = num(balance?.total_deposited_usd, 0);
  const lifetimeWithdrawUsd = num(balance?.total_withdrawn_usd, 0);
  const tonUsdRate      = num(econ.ton_usd_rate, 2.40);
  const usdPerSc        = tonPerScWithdraw * tonUsdRate;
  const liveUsdValue    = Math.max(0, scBalance * usdPerSc);
  const trialActive     = !!balance?.trial_active;
  const trialExpiresAt  = balance?.trial_expires_at ? new Date(balance.trial_expires_at).getTime() : 0;
  const isPaid          = !!balance?.is_paid;
  const [, setTrialTick] = useState(0);
  useEffect(() => {
    if (!trialActive) return;
    const id = setInterval(() => {
      setTrialTick(n => n + 1);
      // Stop polling once trial has expired
      if (Date.now() >= trialExpiresAt) clearInterval(id);
    }, 1000);
    return () => clearInterval(id);
  }, [trialActive, trialExpiresAt]);
  const trialSecs = trialActive ? Math.max(0, Math.floor((trialExpiresAt - Date.now()) / 1000)) : 0;
  const trialH = Math.floor(trialSecs / 3600);
  const trialM = Math.floor((trialSecs % 3600) / 60);
  const trialS = trialSecs % 60;
  const trialText = trialSecs <= 0
    ? 'Expired'
    : trialSecs < 60
      ? `${trialSecs}s remaining`
      : trialH > 0
        ? `${trialH}h ${String(trialM).padStart(2,'0')}m ${String(trialS).padStart(2,'0')}s`
        : `${trialM}m ${String(trialS).padStart(2,'0')}s`;

  function handleAddressChange(val) {
    setTonAddress(val);
    const clean = val.trim();
    if (!clean) { setAddressError(''); return; }
    if (clean.length < 32) { setAddressError('Address too short'); return; }
    if (!TON_ADDRESS_RE.test(clean)) {
      setAddressError('Invalid TON address (must start with UQ or EQ)');
    } else {
      setAddressError('');
    }
  }

  function handleConvertToPaid() {
    if (busy) return;
    showTelegramConfirm('End your free trial now and switch to paid play?', async (confirmed) => {
      if (!confirmed) return;
      setBusy(true); setNotice(null);
      try {
        await convertTrialToPaid();
        setNotice({ type: 'success', text: 'Trial ended. Your account is now paid.' });
        setTimeout(refresh, 300);
      } catch (e) {
        setNotice({ type: 'error', text: e?.message || 'Could not end trial.' });
      } finally { setBusy(false); }
    });
  }

  async function handleCreateTonIntent() {
    if (busy) return;
    if (tonAmount <= 0) { setNotice({ type: 'error', text: `Enter a ${activeCurrencyLabel} amount` }); return; }
    setBusy(true); setNotice(null);
    setIntentConfirmed(false);
    setIntentCredits(0);
    try {
      const res = await createTonDepositIntent(tonAmount);
      if (!res?.ok) {
        setNotice({ type: 'error', text: 'Could not create deposit request' });
        return;
      }
      setTonIntent({
        intentId:    res.intent_id,
        amountTon:   res.amount_ton,
        expectedSc:  res.expected_sc,
        address:     res.expected_address,
        memo:        res.memo,
        currency:    depositCurrency,
      });
      triggerHaptic('success');
    } catch (e) {
      const msg = String(e?.message || e);
      if (msg.includes('below_minimum'))
        setNotice({ type: 'error', text: 'Amount below minimum deposit' });
      else if (msg.includes('too_many_active'))
        setNotice({ type: 'error', text: 'You have too many pending deposit requests. Wait for them to expire.' });
      else
        setNotice({ type: 'error', text: msg });
    } finally { setBusy(false); }
  }

  function copyToClipboard(text, field) {
    if (!text) return;
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    triggerHaptic('success');
    setTimeout(() => setCopiedField(''), 1500);
  }

  function openTonkeeper() {
    if (!tonIntent) return;
    let link;
    if (tonIntent.currency === 'USDT') {
      // USDT jetton transfer link for Tonkeeper
      const USDT_MASTER = 'EQCxE6mUtQJKFnGfaROTKOt1lZbDiiX1kCixRv7Nw2Id_sDs';
      const nano = Math.round(Number(tonIntent.amountTon) * 1_000_000);
      const params = new URLSearchParams();
      params.set('jetton', USDT_MASTER);
      params.set('amount', String(nano));
      if (tonIntent.memo) params.set('text', tonIntent.memo);
      link = `ton://transfer/${tonIntent.address}?${params.toString()}`;
    } else {
      link = buildTonTransferLink(tonIntent.address, tonIntent.amountTon, tonIntent.memo);
    }
    if (!link) return;
    triggerHaptic('success');
    window.location.href = link;
  }

  function openTelegramWallet() {
    triggerHaptic('medium');
    window.open('https://t.me/wallet', '_blank');
  }

  async function handleTestnetWithdraw() {
    if (busy) return;
    const amt = Number(scAmount);
    if (!amt || amt < minWithdrawSc) {
      setNotice({ type: 'error', text: `Minimum withdrawal is ${minWithdrawSc} ${sym}` });
      return;
    }
    if (amt > scBalance) {
      setNotice({ type: 'error', text: 'Insufficient balance' });
      return;
    }
    const clean = tonAddress.trim();
    if (!clean || !TON_ADDRESS_RE.test(clean)) {
      setNotice({ type: 'error', text: 'Enter a valid TON address (UQ... or EQ...)' });
      return;
    }
    setBusy(true); setNotice(null); setTestnetResult(null);
    try {
      const res = await testnetSimulateWithdrawal({ amountSc: amt, tonAddress: clean });
      if (res?.ok) {
        triggerHaptic('success');
        setTestnetResult(res);
        setScAmount(''); setTonAddress(''); setAddressError('');
        setTimeout(refresh, 400);
      } else {
        setNotice({ type: 'error', text: 'Simulation failed' });
      }
    } catch (e) {
      const msg = String(e?.message || e);
      if (msg.includes('insufficient_balance'))
        setNotice({ type: 'error', text: 'Insufficient balance.' });
      else if (msg.includes('below_minimum'))
        setNotice({ type: 'error', text: `Minimum withdrawal is ${minWithdrawSc} ${sym}` });
      else
        setNotice({ type: 'error', text: msg });
    } finally { setBusy(false); }
  }

  async function handleWithdraw() {
    if (busy) return;
    const amt = Number(scAmount);
    if (!amt || amt < minWithdrawSc) {
      setNotice({ type: 'error', text: `Minimum withdrawal is ${minWithdrawSc} ${sym}` });
      return;
    }
    if (amt > scBalance) {
      setNotice({ type: 'error', text: 'Insufficient balance' });
      return;
    }
    const clean = tonAddress.trim();
    if (!clean || !TON_ADDRESS_RE.test(clean)) {
      setNotice({ type: 'error', text: 'Enter a valid TON address (UQ... or EQ...)' });
      return;
    }
    setBusy(true); setNotice(null);
    try {
      const res = await requestTonWithdrawal({ amountSc: amt, tonAddress: clean });
      if (res?.ok) {
        triggerHaptic('success');
        setNotice({ type: 'success', text: `Withdrawal requested: ${res.ton_out} TON. Processing shortly.` });
        setScAmount(''); setTonAddress(''); setAddressError('');
        setTimeout(refresh, 500);
      } else {
        setNotice({ type: 'error', text: 'Could not submit withdrawal' });
      }
    } catch (e) {
      const msg = String(e?.message || e);
      if (msg.includes('withdrawal_cooloff_period'))
        setNotice({ type: 'error', text: 'Please wait 5 minutes before submitting another withdrawal.' });
      else if (msg.includes('daily_request_limit_exceeded'))
        setNotice({ type: 'error', text: 'You have reached your daily limit (3 withdrawal requests per day).' });
      else if (msg.includes('daily_cap_exceeded'))
        setNotice({ type: 'error', text: `Daily cap reached. Max ${num(econ.withdraw_max_sc_day, 50000).toLocaleString()} ${sym}/day.` });
      else if (msg.includes('invalid_ton_address'))
        setNotice({ type: 'error', text: 'Invalid TON address format. Must start with UQ or EQ.' });
      else if (msg.includes('insufficient_balance'))
        setNotice({ type: 'error', text: 'Insufficient balance.' });
      else
        setNotice({ type: 'error', text: msg });
    } finally { setBusy(false); }
  }

  async function handleCancelWithdrawal(id) {
    if (cancellingId) return;
    setCancellingId(id); setNotice(null);
    try {
      const res = await cancelWithdrawal(id);
      if (res?.ok) {
        triggerHaptic('success');
        setNotice({ type: 'success', text: `Withdrawal cancelled. +${res.refunded_sc} ${sym} refunded.` });
        setTimeout(refresh, 400);
      } else {
        setNotice({ type: 'error', text: 'Could not cancel withdrawal.' });
      }
    } catch (e) {
      const msg = String(e?.message || e);
      if (msg.includes('cancel_window_expired'))
        setNotice({ type: 'error', text: 'Cancel window expired (10 minutes after submission).' });
      else if (msg.includes('request_not_cancellable'))
        setNotice({ type: 'error', text: 'This withdrawal is already being processed and cannot be cancelled.' });
      else
        setNotice({ type: 'error', text: msg });
    } finally { setCancellingId(null); }
  }

  const withdrawAmt    = Number(scAmount) || 0;
  const withdrawFee    = Math.max(feeMin, withdrawAmt * feePercent / 100);
  const withdrawNet    = Math.max(0, withdrawAmt - withdrawFee);
  const withdrawTon    = +(withdrawNet * tonPerScWithdraw).toFixed(6);
  const withdrawUsd    = +(withdrawTon * tonUsdRate).toFixed(2);
  const feeUsd         = +(withdrawFee * usdPerSc).toFixed(2);

  const activePendingWithdrawals = pendingWithdrawals.filter(r =>
    ['pending','approved','processing','sent','confirmed'].includes(r.status)
  );

  const trimmedAddress = tonAddress.trim();
  const isWithdrawDisabled = busy || !scAmount || !!addressError
    || !trimmedAddress
    || !TON_ADDRESS_RE.test(trimmedAddress);

  return (
    <motion.div className="px-4 pt-5 pb-6 space-y-4 relative z-10" variants={container} initial="initial" animate="animate">
      <motion.div variants={item} className="flex items-center gap-2.5">
        <WalletIcon size={17} style={{ color: '#10b981', filter: 'drop-shadow(0 0 8px rgba(16,185,129,0.9))' }} />
        <h1 className="font-orbitron text-base font-black text-white tracking-widest">{t(language, 'wallet')}</h1>
      </motion.div>

      {/* Balance Hero */}
      <motion.div variants={item} className="glass-hero rounded-3xl p-5 relative overflow-hidden">
        <div className="absolute -top-10 -right-10 w-44 h-44 rounded-full blur-3xl pointer-events-none"
          style={{ background: 'rgba(16,185,129,0.12)' }} />
        <div className="flex items-center gap-1.5 mb-2 relative z-10">
          <Coins size={11} style={{ color: '#10b981' }} />
          <p className="text-[9px] font-black uppercase tracking-widest" style={{ color: 'rgba(148,163,184,0.78)' }}>
            Real {econ.currency_name || 'Skill Coins'} Balance
          </p>
        </div>
        <div className="flex items-baseline gap-2 mb-1 relative z-10">
          <p className="font-orbitron text-4xl font-black text-white">{scBalance.toLocaleString()}</p>
          <p className="font-orbitron text-sm font-black" style={{ color: '#10b981' }}>{sym}</p>
        </div>
        <div className="flex items-center gap-3 relative z-10">
          <p className="text-[10px]" style={{ color: 'rgba(16,185,129,0.75)' }}>
            ≈ <span className="font-orbitron font-black" style={{ color: '#10b981' }}>${liveUsdValue.toFixed(2)}</span>
            <span style={{ color: 'rgba(148,163,184,0.55)' }}> USD</span>
          </p>
          <p className="text-[10px]" style={{ color: 'rgba(6,182,212,0.75)' }}>
            ≈ <span className="font-orbitron font-black" style={{ color: '#22d3ee' }}>{(scBalance * tonPerScWithdraw).toFixed(4)}</span>
            <span style={{ color: 'rgba(148,163,184,0.55)' }}> TON</span>
          </p>
        </div>
        <p className="text-[10px] relative z-10 mt-0.5" style={{ color: 'rgba(148,163,184,0.55)' }}>
          1 {sym} = ${usdPerSc.toFixed(4)} USD · {tonPerScWithdraw.toFixed(6)} TON
        </p>
        {scPending > 0 && (
          <p className="text-[11px] mt-1 relative z-10" style={{ color: 'rgba(245,158,11,0.85)' }}>
            <Clock size={10} className="inline mr-1" />
            {scPending.toLocaleString()} {sym} pending withdrawal
          </p>
        )}
      </motion.div>

      {/* Active Withdrawal Requests */}
      <AnimatePresence>
        {activePendingWithdrawals.length > 0 && (
          <motion.div
            key="pending-withdrawals"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-2"
          >
            <p className="text-[9px] font-black uppercase tracking-widest px-1"
              style={{ color: 'rgba(148,163,184,0.6)' }}>
              Withdrawal Requests
            </p>
            {activePendingWithdrawals.map(req => (
              <div key={req.id} className="rounded-2xl p-3.5"
                style={{ background: 'rgba(0,0,0,0.35)', border: '1px solid rgba(255,255,255,0.07)' }}>
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <WithdrawalStatusBadge status={req.status} />
                      <span className="text-[10px]" style={{ color: 'rgba(148,163,184,0.6)' }}>
                        {formatRelativeTime(req.created_at)}
                      </span>
                    </div>
                    <p className="font-orbitron text-sm font-black text-white">
                      {req.ton_out} TON
                      <span className="font-normal text-[10px] ml-1.5" style={{ color: 'rgba(148,163,184,0.6)' }}>
                        ({req.amount_sc} {sym})
                      </span>
                    </p>
                    {req.tx_hash && (
                      <p className="text-[10px] mt-0.5 font-mono truncate" style={{ color: '#22d3ee', maxWidth: '180px' }}>
                        tx: {req.tx_hash.slice(0, 16)}…
                      </p>
                    )}
                    {req.admin_note && (
                      <p className="text-[10px] mt-0.5" style={{ color: 'rgba(245,158,11,0.8)' }}>
                        {req.admin_note}
                      </p>
                    )}
                  </div>
                  {req.can_cancel && (
                    <button
                      onClick={() => handleCancelWithdrawal(req.id)}
                      disabled={!!cancellingId}
                      className="flex-shrink-0 flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[10px] font-black transition-all"
                      style={{
                        background: 'rgba(244,63,94,0.10)',
                        border: '1px solid rgba(244,63,94,0.25)',
                        color: '#fb7185',
                        opacity: cancellingId ? 0.5 : 1,
                        cursor: cancellingId ? 'wait' : 'pointer',
                      }}>
                      {cancellingId === req.id
                        ? <RefreshCw size={10} className="animate-spin" />
                        : <X size={10} />}
                      Cancel
                    </button>
                  )}
                </div>
              </div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Free Trial Timer */}
      <motion.div variants={item} className="glass-card rounded-2xl p-4 relative overflow-hidden"
        style={{ border: trialActive ? '1px solid rgba(245,158,11,0.30)' : '1px solid rgba(148,163,184,0.15)' }}>
        <div className="absolute -top-8 -right-8 w-32 h-32 rounded-full blur-3xl pointer-events-none"
          style={{ background: trialActive ? 'rgba(245,158,11,0.14)' : 'rgba(148,163,184,0.05)' }} />
        <div className="flex items-center justify-between relative z-10 gap-3">
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 mb-2">
              {trialActive
                ? <Clock size={11} style={{ color: '#fbbf24' }} />
                : <Gift size={11} style={{ color: 'rgba(148,163,184,0.6)' }} />}
              <p className="text-[9px] font-black uppercase tracking-widest" style={{ color: 'rgba(148,163,184,0.78)' }}>
                Free Trial
              </p>
            </div>
            {trialActive ? (
              <>
                <p className="font-orbitron text-xl font-black text-white">{trialText}</p>
                <p className="text-[10px] mt-1" style={{ color: 'rgba(245,158,11,0.85)' }}>
                  Solo games are free until trial ends
                </p>
              </>
            ) : (
              <>
                <p className="font-orbitron text-base font-black text-white">{isPaid ? 'Paid Account' : 'Trial Ended'}</p>
                <p className="text-[10px] mt-1" style={{ color: 'rgba(148,163,184,0.65)' }}>
                  Solo games deduct {sym} from your wallet
                </p>
              </>
            )}
          </div>
          {trialActive && (
            <button onClick={handleConvertToPaid} disabled={busy}
              className="flex-shrink-0 px-3 py-2 rounded-lg text-[10px] font-black uppercase tracking-wider"
              style={{
                background: 'rgba(16,185,129,0.10)', border: '1px solid rgba(16,185,129,0.35)',
                color: '#10b981', fontFamily: 'Orbitron, sans-serif',
                cursor: busy ? 'wait' : 'pointer', opacity: busy ? 0.6 : 1,
              }}>
              End Trial<br/>Play Paid
            </button>
          )}
        </div>
      </motion.div>

      {/* Lifetime Stats */}
      <motion.div variants={item} className="grid grid-cols-3 gap-2">
        <LifetimeStat label="Earned"    value={`${lifetimeWonUsd.toLocaleString()} ${sym}`}     color="#10b981" />
        <LifetimeStat label="Deposited" value={`${lifetimeDepositUsd.toLocaleString()} ${sym}`}  color="#22d3ee" />
        <LifetimeStat label="Withdrawn" value={`${lifetimeWithdrawUsd.toLocaleString()} ${sym}`} color="#f59e0b" />
      </motion.div>

      {/* Tabs */}
      <motion.div variants={item} className="flex gap-1.5 glass-card rounded-2xl p-1">
        {[
          { id: 'buy',      label: 'Buy',      icon: ArrowDownLeft },
          { id: 'withdraw', label: 'Withdraw', icon: ArrowUpRight  },
          { id: 'history',  label: 'History',  icon: Clock         },
        ].map(({ id, label, icon: Icon }) => (
          <button key={id} onClick={() => { setTab(id); setNotice(null); }}
            className="flex-1 py-2.5 rounded-xl font-black text-xs flex items-center justify-center gap-1.5 transition-all duration-200"
            style={tab === id ? {
              background: 'linear-gradient(135deg, #047857, #10b981)',
              border: '1px solid rgba(16,185,129,0.35)',
              color: '#fff',
              boxShadow: '0 0 24px rgba(5,150,105,0.4)',
              fontFamily: 'Orbitron, sans-serif',
              letterSpacing: '0.08em',
            } : { color: 'rgba(148,163,184,0.6)' }}>
            <Icon size={13}/>{label}
          </button>
        ))}
      </motion.div>

      {/* Notice */}
      <AnimatePresence>
        {notice && (
          <motion.div
            key="notice"
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            className="flex gap-2.5 rounded-xl p-3"
            style={{
              background: notice.type === 'success' ? 'rgba(16,185,129,0.07)'
                        : notice.type === 'error'   ? 'rgba(244,63,94,0.07)'
                        : notice.type === 'warning' ? 'rgba(245,158,11,0.07)'
                                                    : 'rgba(0,212,255,0.07)',
              border: `1px solid ${
                notice.type === 'success' ? 'rgba(16,185,129,0.25)'
                : notice.type === 'error' ? 'rgba(244,63,94,0.25)'
                : notice.type === 'warning' ? 'rgba(245,158,11,0.25)'
                : 'rgba(0,212,255,0.25)'
              }`,
            }}>
            {notice.type === 'success'
              ? <CheckCircle2 size={14} className="text-emerald-400 flex-shrink-0 mt-0.5" />
              : <AlertCircle size={14} className="flex-shrink-0 mt-0.5" style={{
                  color: notice.type === 'error' ? '#fb7185'
                        : notice.type === 'warning' ? '#fbbf24' : '#67e8f9',
                }} />}
            <p className="text-sm font-medium" style={{
              color: notice.type === 'success' ? '#6ee7b7'
                  : notice.type === 'error' ? '#fda4af'
                  : notice.type === 'warning' ? '#fcd34d' : '#a5f3fc',
            }}>{notice.text}</p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── BUY tab ─────────────────────────────────────────────────────────── */}
      {tab === 'buy' && (
        <>
          {/* Admin deposit note */}
          {depositNote && (
            <div style={{ padding: '10px 14px', borderRadius: 12, background: 'rgba(34,211,238,0.07)', border: '1px solid rgba(34,211,238,0.2)', marginBottom: 4 }}>
              <p style={{ fontSize: 12, color: 'rgba(34,211,238,0.9)', lineHeight: 1.5 }}>{depositNote}</p>
            </div>
          )}
          {/* ── CONFIRMED ── */}
          <AnimatePresence>
            {intentConfirmed && (
              <motion.div
                key="confirmed"
                initial={{ opacity: 0, scale: 0.92, y: 16 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0 }}
                transition={{ type: 'spring', stiffness: 300, damping: 26 }}
                className="rounded-3xl p-6 text-center relative overflow-hidden"
                style={{
                  background: 'linear-gradient(135deg, rgba(16,185,129,0.14), rgba(5,150,105,0.08))',
                  border: '1px solid rgba(16,185,129,0.45)',
                  boxShadow: '0 0 60px rgba(16,185,129,0.18)',
                }}
              >
                <div className="absolute inset-0 pointer-events-none" style={{ background: 'radial-gradient(circle at 50% 30%, rgba(16,185,129,0.12), transparent 70%)' }} />
                <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 relative z-10"
                  style={{ background: 'rgba(16,185,129,0.18)', border: '2px solid rgba(16,185,129,0.5)', boxShadow: '0 0 32px rgba(16,185,129,0.3)' }}>
                  <CheckCircle2 size={32} style={{ color: '#10b981' }} />
                </div>
                <p className="font-orbitron text-lg font-black text-white mb-1 relative z-10">Deposit Confirmed!</p>
                <p className="font-orbitron text-3xl font-black mb-2 relative z-10" style={{ color: '#10b981' }}>+{Number(intentCredits).toLocaleString()} {sym}</p>
                <p className="text-[11px] relative z-10" style={{ color: 'rgba(148,163,184,0.7)' }}>Added to your balance. Ready to play!</p>
                <button
                  onClick={() => { setTonIntent(null); setIntentConfirmed(false); setIntentCredits(0); }}
                  className="mt-4 px-5 py-2 rounded-xl text-xs font-black relative z-10"
                  style={{ background: 'rgba(16,185,129,0.15)', border: '1px solid rgba(16,185,129,0.35)', color: '#10b981' }}>
                  Deposit More
                </button>
              </motion.div>
            )}
          </AnimatePresence>

          {!intentConfirmed && !tonIntent && (
            <motion.div variants={item} className="space-y-3">

              {/* ── @wallet hero card ── */}
              {walletEnabled && (
                <div className="rounded-3xl p-5 relative overflow-hidden"
                  style={{
                    background: 'linear-gradient(135deg, rgba(41,128,185,0.22), rgba(23,162,184,0.12))',
                    border: '1px solid rgba(41,182,246,0.38)',
                    boxShadow: '0 0 40px rgba(41,182,246,0.10)',
                  }}>
                  <div className="absolute -top-8 -right-8 w-36 h-36 rounded-full blur-3xl pointer-events-none"
                    style={{ background: 'rgba(41,182,246,0.14)' }} />

                  {/* Header row */}
                  <div className="flex items-center gap-3 mb-3 relative z-10">
                    <div className="w-11 h-11 rounded-2xl flex items-center justify-center flex-shrink-0"
                      style={{ background: 'rgba(41,182,246,0.22)', border: '1px solid rgba(41,182,246,0.45)' }}>
                      <span style={{ fontSize: 22 }}>💎</span>
                    </div>
                    <div>
                      <p className="font-black text-white text-sm leading-tight">Buy with @wallet</p>
                      <p className="text-[10px] mt-0.5" style={{ color: 'rgba(148,163,184,0.75)' }}>{walletHint}</p>
                    </div>
                  </div>

                  {/* Steps */}
                  <div className="space-y-2 mb-4 relative z-10">
                    {[walletStep1, walletStep2, walletStep3].map((step, i) => (
                      <div key={i} className="flex items-start gap-2.5">
                        <div className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5"
                          style={{ background: 'rgba(41,182,246,0.25)', border: '1px solid rgba(41,182,246,0.5)' }}>
                          <span className="text-[9px] font-black" style={{ color: '#7dd3fc' }}>{i + 1}</span>
                        </div>
                        <p className="text-[11px] leading-relaxed" style={{ color: 'rgba(203,213,225,0.85)' }}>{step}</p>
                      </div>
                    ))}
                  </div>

                  {/* Open @wallet button */}
                  <button
                    onClick={openTelegramWallet}
                    className="w-full py-3.5 rounded-2xl font-black text-sm flex items-center justify-center gap-2 relative z-10 transition-all active:scale-95"
                    style={{
                      background: 'linear-gradient(135deg, #1d6fa4, #2596be)',
                      color: '#fff',
                      fontFamily: 'Orbitron, sans-serif',
                      letterSpacing: '0.07em',
                      boxShadow: '0 4px 32px rgba(41,182,246,0.35)',
                      border: '1px solid rgba(41,182,246,0.4)',
                    }}>
                    <span style={{ fontSize: 16 }}>💬</span>
                    OPEN @WALLET
                    <ChevronRight size={14} />
                  </button>
                </div>
              )}

              {/* ── Amount picker ── */}
              <div className="glass-card rounded-2xl p-4 space-y-3">

                {/* Currency selector */}
                <div>
                  <p className="text-[9px] font-black uppercase tracking-widest mb-2" style={{ color: 'rgba(148,163,184,0.78)' }}>
                    Choose currency
                  </p>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setDepositCurrency('TON')}
                      className="flex items-center justify-center gap-2 py-2.5 rounded-xl font-black text-xs transition-all"
                      style={depositCurrency === 'TON' ? {
                        background: 'rgba(6,182,212,0.15)',
                        border: '2px solid rgba(6,182,212,0.55)',
                        color: '#22d3ee',
                        boxShadow: '0 0 16px rgba(6,182,212,0.20)',
                      } : {
                        background: 'rgba(255,255,255,0.03)',
                        border: '1px solid rgba(255,255,255,0.08)',
                        color: 'rgba(148,163,184,0.6)',
                      }}>
                      <span style={{ fontSize: 16 }}>💎</span>
                      TON
                    </button>
                    {usdtDepositEnabled && (
                      <button
                        onClick={() => setDepositCurrency('USDT')}
                        className="flex items-center justify-center gap-2 py-2.5 rounded-xl font-black text-xs transition-all"
                        style={depositCurrency === 'USDT' ? {
                          background: 'rgba(38,161,123,0.15)',
                          border: '2px solid rgba(38,161,123,0.55)',
                          color: '#4ade80',
                          boxShadow: '0 0 16px rgba(38,161,123,0.20)',
                        } : {
                          background: 'rgba(255,255,255,0.03)',
                          border: '1px solid rgba(255,255,255,0.08)',
                          color: 'rgba(148,163,184,0.6)',
                        }}>
                        <span style={{ fontSize: 16 }}>💵</span>
                        USDT
                      </button>
                    )}
                  </div>
                </div>

                <p className="text-[9px] font-black uppercase tracking-widest" style={{ color: 'rgba(148,163,184,0.78)' }}>
                  Then choose how much {activeCurrencyLabel} to send
                </p>
                <div>
                  <div className="grid grid-cols-5 gap-1.5 mb-2">
                    {TON_PRESETS.map(p => (
                      <button key={p} onClick={() => setTonAmount(p)}
                        className="py-2 rounded-lg text-xs font-black transition-all"
                        style={tonAmount === p ? {
                          background: depositCurrency === 'USDT' ? 'rgba(38,161,123,0.15)' : 'rgba(41,182,246,0.15)',
                          border: `1px solid ${depositCurrency === 'USDT' ? 'rgba(38,161,123,0.45)' : 'rgba(41,182,246,0.4)'}`,
                          color: depositCurrency === 'USDT' ? '#4ade80' : '#7dd3fc',
                        } : {
                          background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)', color: 'rgba(148,163,184,0.7)',
                        }}>{p}</button>
                    ))}
                  </div>
                  <input type="number" value={tonAmount} step="0.1" min="0"
                    onChange={e => setTonAmount(Math.max(0, Number(e.target.value) || 0))}
                    className="glass-input w-full rounded-xl px-4 py-3 text-white text-base font-black" />
                </div>
                <div className="flex items-center justify-between p-3 rounded-xl"
                  style={{ background: 'rgba(16,185,129,0.06)', border: '1px solid rgba(16,185,129,0.15)' }}>
                  <p className="text-xs" style={{ color: 'rgba(148,163,184,0.7)' }}>You will receive</p>
                  <p className="font-orbitron text-base font-black" style={{ color: '#10b981' }}>
                    +{Number((tonAmount * activeCurrencyRate).toFixed(2))} {sym}
                  </p>
                </div>
                <button onClick={handleCreateTonIntent} disabled={busy || tonAmount <= 0}
                  className="w-full py-3.5 rounded-xl font-black text-sm transition-all active:scale-95"
                  style={(busy || tonAmount <= 0) ? {
                    background: 'rgba(255,255,255,0.04)', color: 'rgba(100,100,120,0.5)', cursor: 'not-allowed',
                  } : depositCurrency === 'USDT' ? {
                    background: 'linear-gradient(135deg, #065f46, #10b981)',
                    color: '#fff', fontFamily: 'Orbitron, sans-serif', letterSpacing: '0.08em',
                    boxShadow: '0 0 24px rgba(16,185,129,0.35)',
                  } : {
                    background: 'linear-gradient(135deg, #0369a1, #06b6d4)',
                    color: '#fff', fontFamily: 'Orbitron, sans-serif', letterSpacing: '0.08em',
                    boxShadow: '0 0 24px rgba(6,182,212,0.35)',
                  }}>
                  <Zap size={14} className="inline mr-2 mb-0.5" />
                  {busy ? 'PREPARING…' : `GET DEPOSIT ADDRESS — ${tonAmount} ${activeCurrencyLabel}`}
                </button>
              </div>

              {/* Tonkeeper alternative */}
              {tonkeeperPromoEnabled && (
                <div className="rounded-xl px-4 py-3 flex items-center gap-3"
                  style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.06)' }}>
                  <Download size={13} style={{ color: 'rgba(148,163,184,0.5)', flexShrink: 0 }} />
                  <p className="text-[10px] flex-1" style={{ color: 'rgba(148,163,184,0.6)' }}>
                    Already have crypto? Use{' '}
                    <a href={tonkeeperUrl} target="_blank" rel="noopener noreferrer"
                      style={{ color: '#67e8f9', fontWeight: 700 }}>Tonkeeper</a>{' '}
                    to send TON directly.
                  </p>
                </div>
              )}
            </motion.div>
          )}

          {!intentConfirmed && tonIntent && (
            <motion.div
              key="intent"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-3"
            >
              {/* ── SKZ Secret Code Hero Card ── */}
              <div className="rounded-3xl p-5 relative overflow-hidden"
                style={{
                  background: 'linear-gradient(135deg, rgba(15,23,42,0.95), rgba(10,18,36,0.98))',
                  border: '1px solid rgba(245,158,11,0.45)',
                  boxShadow: '0 0 60px rgba(245,158,11,0.12), inset 0 1px 0 rgba(255,255,255,0.05)',
                }}>
                <div className="absolute -top-12 -right-12 w-48 h-48 rounded-full blur-3xl pointer-events-none"
                  style={{ background: 'rgba(245,158,11,0.10)' }} />
                <div className="absolute -bottom-8 -left-8 w-32 h-32 rounded-full blur-2xl pointer-events-none"
                  style={{ background: 'rgba(6,182,212,0.08)' }} />

                {/* Header */}
                <div className="flex items-center justify-between mb-4 relative z-10">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-xl flex items-center justify-center"
                      style={{ background: 'rgba(245,158,11,0.18)', border: '1px solid rgba(245,158,11,0.4)' }}>
                      <Sparkles size={14} style={{ color: '#fbbf24' }} />
                    </div>
                    <div>
                      <p className="text-[10px] font-black uppercase tracking-widest" style={{ color: 'rgba(245,158,11,0.9)' }}>
                        Your Secret Code
                      </p>
                      <p className="text-[9px]" style={{ color: 'rgba(148,163,184,0.55)' }}>
                        Copy &amp; paste in transfer comment
                      </p>
                    </div>
                  </div>
                  <button onClick={() => { setTonIntent(null); setIntentConfirmed(false); }}
                    className="text-[10px] font-bold px-2.5 py-1.5 rounded-lg transition-all"
                    style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.09)', color: 'rgba(148,163,184,0.55)' }}>
                    New
                  </button>
                </div>

                {/* The SKZ Code — large, prominent, branded */}
                <div className="relative z-10 mb-4">
                  <div
                    className="rounded-2xl px-4 py-4 flex items-center justify-between gap-3 cursor-pointer transition-all active:scale-95"
                    onClick={() => copyToClipboard(tonIntent.memo, 'memo')}
                    style={{
                      background: copiedField === 'memo'
                        ? 'rgba(16,185,129,0.12)'
                        : 'rgba(245,158,11,0.07)',
                      border: copiedField === 'memo'
                        ? '2px solid rgba(16,185,129,0.5)'
                        : '2px solid rgba(245,158,11,0.55)',
                      boxShadow: copiedField === 'memo'
                        ? '0 0 24px rgba(16,185,129,0.18)'
                        : '0 0 24px rgba(245,158,11,0.12)',
                    }}>
                    <div className="flex-1 text-center">
                      <span className="font-orbitron font-black"
                        style={{
                          fontSize: 22,
                          letterSpacing: '0.18em',
                          color: copiedField === 'memo' ? '#6ee7b7' : '#fbbf24',
                        }}>
                        {tonIntent.memo}
                      </span>
                    </div>
                    <div className="flex-shrink-0 w-9 h-9 rounded-xl flex items-center justify-center"
                      style={{
                        background: copiedField === 'memo' ? 'rgba(16,185,129,0.2)' : 'rgba(245,158,11,0.18)',
                        border: `1px solid ${copiedField === 'memo' ? 'rgba(16,185,129,0.4)' : 'rgba(245,158,11,0.35)'}`,
                      }}>
                      {copiedField === 'memo'
                        ? <CheckCircle2 size={16} style={{ color: '#10b981' }} />
                        : <Copy size={16} style={{ color: '#fbbf24' }} />}
                    </div>
                  </div>
                  <p className="text-center text-[10px] mt-2"
                    style={{ color: copiedField === 'memo' ? '#6ee7b7' : 'rgba(148,163,184,0.5)' }}>
                    {copiedField === 'memo' ? 'Copied to clipboard!' : 'Tap to copy'}
                  </p>
                </div>

                {/* Amount row */}
                <div className="rounded-xl px-4 py-3 flex items-center justify-between relative z-10"
                  style={{ background: 'rgba(16,185,129,0.07)', border: '1px solid rgba(16,185,129,0.18)' }}>
                  <div>
                    <p className="text-[9px] font-black uppercase tracking-widest" style={{ color: 'rgba(148,163,184,0.65)' }}>Send exactly</p>
                    <p className="font-orbitron text-lg font-black text-white">
                      {tonIntent.amountTon} {tonIntent.currency || 'TON'}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-[9px] font-black uppercase tracking-widest" style={{ color: 'rgba(148,163,184,0.65)' }}>You receive</p>
                    <p className="font-orbitron text-lg font-black" style={{ color: '#10b981' }}>+{tonIntent.expectedSc} {sym}</p>
                  </div>
                </div>

                {/* Waiting pulse */}
                <div className="flex items-center gap-2.5 mt-3 relative z-10">
                  <RefreshCw size={12} style={{ color: '#7dd3fc', flexShrink: 0, animation: 'spin 1.8s linear infinite' }} />
                  <p className="text-[10px]" style={{ color: 'rgba(148,163,184,0.65)' }}>
                    Waiting for transfer… balance updates automatically.
                  </p>
                </div>
              </div>

              {/* ── Send buttons ── */}
              <div className="space-y-2">
                {/* Tonkeeper — auto-fills everything */}
                <button onClick={openTonkeeper}
                  className="w-full py-4 rounded-2xl font-black text-sm flex items-center justify-center gap-2.5 transition-all active:scale-95"
                  style={tonIntent.currency === 'USDT' ? {
                    background: 'linear-gradient(135deg, #064e3b, #065f46)',
                    color: '#fff', fontFamily: 'Orbitron, sans-serif', letterSpacing: '0.07em',
                    boxShadow: '0 4px 32px rgba(16,185,129,0.30)',
                    border: '1px solid rgba(16,185,129,0.45)',
                  } : {
                    background: 'linear-gradient(135deg, #0c4a6e, #0369a1)',
                    color: '#fff', fontFamily: 'Orbitron, sans-serif', letterSpacing: '0.07em',
                    boxShadow: '0 4px 32px rgba(6,182,212,0.30)',
                    border: '1px solid rgba(6,182,212,0.35)',
                  }}>
                  <Zap size={15} style={{ color: tonIntent.currency === 'USDT' ? '#6ee7b7' : '#7dd3fc' }} />
                  SEND {tonIntent.currency || 'TON'} VIA TONKEEPER
                  <span className="text-[9px] font-normal opacity-70 normal-case tracking-normal ml-0.5"
                    style={{ fontFamily: 'inherit' }}>(auto-fill)</span>
                </button>

                {/* @wallet */}
                {walletEnabled && (
                  <button onClick={openTelegramWallet}
                    className="w-full py-3.5 rounded-2xl font-black text-sm flex items-center justify-center gap-2 transition-all active:scale-95"
                    style={{
                      background: 'rgba(41,182,246,0.08)',
                      color: '#7dd3fc', fontFamily: 'Orbitron, sans-serif', letterSpacing: '0.07em',
                      border: '1px solid rgba(41,182,246,0.3)',
                    }}>
                    <span style={{ fontSize: 15 }}>💬</span>
                    OPEN @WALLET
                    <ExternalLink size={12} style={{ opacity: 0.7 }} />
                  </button>
                )}
              </div>

              {/* ── Destination address ── */}
              <div className="glass-card rounded-2xl p-4 space-y-3">
                <p className="text-[9px] font-black uppercase tracking-widest" style={{ color: 'rgba(148,163,184,0.55)' }}>
                  Deposit Address
                </p>
                <div className="flex items-center gap-2">
                  <code className="flex-1 rounded-lg px-3 py-2.5 text-[11px] text-white font-mono break-all"
                    style={{ background: 'rgba(0,0,0,0.4)', border: '1px solid rgba(255,255,255,0.08)' }}>
                    {tonIntent.address || '—'}
                  </code>
                  <button onClick={() => copyToClipboard(tonIntent.address, 'addr')}
                    className="p-2.5 rounded-lg flex-shrink-0 transition-all"
                    style={{
                      background: copiedField === 'addr' ? 'rgba(16,185,129,0.15)' : 'rgba(41,182,246,0.12)',
                      border: `1px solid ${copiedField === 'addr' ? 'rgba(16,185,129,0.3)' : 'rgba(41,182,246,0.25)'}`,
                    }}>
                    {copiedField === 'addr'
                      ? <CheckCircle2 size={14} className="text-emerald-400" />
                      : <Copy size={14} style={{ color: '#7dd3fc' }} />}
                  </button>
                </div>

                {/* Warning */}
                <div className="rounded-xl p-3 flex gap-2.5"
                  style={{ background: 'rgba(239,68,68,0.07)', border: '1px solid rgba(239,68,68,0.28)' }}>
                  <AlertTriangle size={13} style={{ color: '#f87171', flexShrink: 0, marginTop: 1 }} />
                  <p className="text-[10px] leading-relaxed" style={{ color: '#fca5a5' }}>
                    <span className="font-black text-white">Paste the code</span> in the Comment/Memo field when sending.
                    Without it, <span className="font-black" style={{ color: '#f87171' }}>funds cannot be credited.</span>
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <Clock size={10} style={{ color: 'rgba(148,163,184,0.5)' }} />
                  <p className="text-[10px]" style={{ color: 'rgba(148,163,184,0.6)' }}>
                    Credited within ~{tonEta} min after on-chain confirmation.
                  </p>
                </div>
              </div>
            </motion.div>
          )}
        </>
      )}

      {/* ── WITHDRAW tab ────────────────────────────────────────────────────── */}
      {tab === 'withdraw' && (
        <motion.div variants={item} className="space-y-3">

          {/* Testnet mode banner */}
          {isTestnet && (
            <div className="rounded-2xl p-3 flex items-start gap-2.5"
              style={{ background: 'rgba(251,191,36,0.08)', border: '1px solid rgba(251,191,36,0.35)' }}>
              <AlertTriangle size={13} style={{ color: '#fbbf24', marginTop: 1, flexShrink: 0 }} />
              <div>
                <p className="text-[10px] font-black uppercase tracking-wider mb-0.5" style={{ color: '#fbbf24' }}>
                  Testnet Mode Active
                </p>
                <p className="text-[10px] leading-relaxed" style={{ color: 'rgba(251,191,36,0.75)' }}>
                  Simulated transactions only — no real TON is sent. L1 (5%) and L2 (2%) commissions are calculated and credited in the DB.
                </p>
              </div>
            </div>
          )}

          {!isTestnet && (
            <div className="rounded-2xl p-3 flex items-start gap-2.5"
              style={{ background: 'rgba(16,185,129,0.06)', border: '1px solid rgba(16,185,129,0.15)' }}>
              <ShieldCheck size={13} style={{ color: '#10b981', marginTop: 1, flexShrink: 0 }} />
              <p className="text-[10px] leading-relaxed" style={{ color: 'rgba(148,163,184,0.75)' }}>
                Min {minWithdrawSc.toLocaleString()} {sym} · Max {num(econ.withdraw_max_sc_day, 50000).toLocaleString()} {sym}/day · 3 requests/day · 5-min cooloff · Cancel within 10 min
              </p>
            </div>
          )}

          {/* Testnet simulated result */}
          <AnimatePresence>
            {testnetResult && (
              <motion.div
                key="testnet-result"
                initial={{ opacity: 0, y: -8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="rounded-2xl overflow-hidden"
                style={{ border: '1px solid rgba(251,191,36,0.4)', background: 'rgba(10,14,22,0.95)' }}
              >
                {/* Header */}
                <div className="flex items-center justify-between px-4 py-3"
                  style={{ background: 'rgba(251,191,36,0.1)', borderBottom: '1px solid rgba(251,191,36,0.2)' }}>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 size={14} style={{ color: '#fbbf24' }} />
                    <span className="text-[11px] font-black uppercase tracking-wider" style={{ color: '#fbbf24' }}>
                      Testnet TX Simulated
                    </span>
                  </div>
                  <button onClick={() => setTestnetResult(null)}
                    className="text-[10px] px-2 py-1 rounded-lg"
                    style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', color: 'rgba(148,163,184,0.7)' }}>
                    Dismiss
                  </button>
                </div>

                {/* TX Hash */}
                <div className="px-4 pt-3 pb-2">
                  <p className="text-[8px] font-black uppercase tracking-widest mb-1" style={{ color: 'rgba(148,163,184,0.5)' }}>Transaction Hash</p>
                  <div className="flex items-center gap-2">
                    <code className="flex-1 text-[10px] font-mono truncate" style={{ color: '#fbbf24' }}>{testnetResult.tx_hash}</code>
                    <button onClick={() => copyToClipboard(testnetResult.tx_hash, 'txhash')}
                      className="p-1.5 rounded-lg flex-shrink-0"
                      style={{ background: 'rgba(251,191,36,0.1)', border: '1px solid rgba(251,191,36,0.25)' }}>
                      {copiedField === 'txhash' ? <CheckCircle2 size={11} style={{ color: '#fbbf24' }} /> : <Copy size={11} style={{ color: '#fbbf24' }} />}
                    </button>
                    <a href={`${testnetExplorer}${testnetResult.tx_hash}`} target="_blank" rel="noopener noreferrer"
                      className="p-1.5 rounded-lg flex-shrink-0"
                      style={{ background: 'rgba(34,211,238,0.1)', border: '1px solid rgba(34,211,238,0.2)' }}>
                      <ExternalLink size={11} style={{ color: '#22d3ee' }} />
                    </a>
                  </div>
                </div>

                {/* Block + From/To */}
                <div className="grid grid-cols-2 gap-2 px-4 py-2">
                  <div style={{ padding: '7px 10px', borderRadius: 10, background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)' }}>
                    <p className="text-[8px] font-black uppercase tracking-wider mb-0.5" style={{ color: 'rgba(148,163,184,0.45)' }}>Block</p>
                    <p className="text-[11px] font-black font-mono" style={{ color: '#e2e8f0' }}>{testnetResult.block_height?.toLocaleString()}</p>
                  </div>
                  <div style={{ padding: '7px 10px', borderRadius: 10, background: 'rgba(16,185,129,0.06)', border: '1px solid rgba(16,185,129,0.15)' }}>
                    <p className="text-[8px] font-black uppercase tracking-wider mb-0.5" style={{ color: 'rgba(148,163,184,0.45)' }}>TON Sent</p>
                    <p className="text-[11px] font-black font-mono" style={{ color: '#10b981' }}>{testnetResult.ton_out} TON</p>
                  </div>
                </div>

                {/* Breakdown */}
                <div className="px-4 pb-3 space-y-1.5 text-[10px]">
                  <div className="flex justify-between py-1" style={{ borderBottom: '1px solid rgba(255,255,255,0.05)', color: 'rgba(148,163,184,0.7)' }}>
                    <span>Amount</span><span>{testnetResult.amount_skz} {sym}</span>
                  </div>
                  <div className="flex justify-between py-1" style={{ borderBottom: '1px solid rgba(255,255,255,0.05)', color: 'rgba(148,163,184,0.7)' }}>
                    <span>Fee (2%, min 50)</span><span style={{ color: '#f87171' }}>−{testnetResult.fee_skz} {sym}</span>
                  </div>
                  <div className="flex justify-between py-1" style={{ borderBottom: '1px solid rgba(255,255,255,0.05)', color: 'rgba(148,163,184,0.7)' }}>
                    <span>Net</span><span>{testnetResult.net_skz} {sym}</span>
                  </div>

                  {/* Commission rows */}
                  {(testnetResult.l1_commission > 0 || testnetResult.l2_commission > 0) && (
                    <div className="rounded-lg p-2.5 mt-1"
                      style={{ background: 'rgba(245,158,11,0.06)', border: '1px solid rgba(245,158,11,0.2)' }}>
                      <p className="text-[8px] font-black uppercase tracking-wider mb-1.5" style={{ color: 'rgba(245,158,11,0.7)' }}>
                        Commission Distribution
                      </p>
                      {testnetResult.l1_commission > 0 && (
                        <div className="flex justify-between" style={{ color: 'rgba(148,163,184,0.7)' }}>
                          <span>L1 Referrer (5%)</span>
                          <span style={{ color: '#fbbf24' }}>+{testnetResult.l1_commission} {sym} → #{testnetResult.l1_referrer}</span>
                        </div>
                      )}
                      {testnetResult.l2_commission > 0 && (
                        <div className="flex justify-between mt-1" style={{ color: 'rgba(148,163,184,0.7)' }}>
                          <span>L2 Referrer (2% of L1)</span>
                          <span style={{ color: '#f59e0b' }}>+{testnetResult.l2_commission} {sym} → #{testnetResult.l2_referrer}</span>
                        </div>
                      )}
                      {testnetResult.l1_commission === 0 && (
                        <p className="text-[9px]" style={{ color: 'rgba(148,163,184,0.45)' }}>No referrer on record — 0 commission</p>
                      )}
                    </div>
                  )}

                  {/* From wallet */}
                  <div className="pt-1">
                    <p className="text-[8px] font-black uppercase tracking-wider mb-0.5" style={{ color: 'rgba(148,163,184,0.4)' }}>From (Testnet Hot Wallet)</p>
                    <code className="text-[9px] font-mono break-all" style={{ color: 'rgba(34,211,238,0.7)' }}>{testnetResult.from_address}</code>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Withdrawal form */}
          <div className="glass-card rounded-2xl p-4 space-y-3">

            {isTestnet && (
              <div className="rounded-xl p-2.5 flex items-center gap-2"
                style={{ background: 'rgba(251,191,36,0.06)', border: '1px solid rgba(251,191,36,0.18)' }}>
                <span style={{ fontSize: 14 }}>🧪</span>
                <div>
                  <p className="text-[9px] font-black uppercase tracking-wider" style={{ color: '#fbbf24' }}>Testnet Wallet</p>
                  <code className="text-[9px] font-mono" style={{ color: 'rgba(251,191,36,0.7)' }}>{testnetWallet}</code>
                </div>
              </div>
            )}

            <div>
              <label className="text-[9px] font-black uppercase tracking-widest block mb-2"
                style={{ color: 'rgba(148,163,184,0.78)' }}>Amount ({sym})</label>
              <input type="number" value={scAmount} onChange={e => setScAmount(e.target.value)}
                placeholder={`min ${minWithdrawSc}`}
                className="glass-input w-full rounded-xl px-4 py-3 text-white text-base font-black" />
            </div>

            <div>
              <label className="text-[9px] font-black uppercase tracking-widest block mb-2"
                style={{ color: 'rgba(148,163,184,0.78)' }}>
                {isTestnet ? 'Your Testnet TON Address' : 'Your TON Wallet Address'}
              </label>
              <input type="text" value={tonAddress} onChange={e => handleAddressChange(e.target.value)}
                placeholder="UQ... or EQ..."
                className="glass-input w-full rounded-xl px-4 py-3 text-white text-xs font-mono"
                style={addressError ? { borderColor: 'rgba(244,63,94,0.4)' } : {}} />
              <AnimatePresence>
                {tonAddress && !addressError && TON_ADDRESS_RE.test(tonAddress.trim()) && (
                  <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}
                    className="flex items-center gap-1.5 mt-1.5">
                    <CheckCircle2 size={11} className="text-emerald-400" />
                    <p className="text-[10px]" style={{ color: '#6ee7b7' }}>Valid TON address</p>
                  </motion.div>
                )}
                {addressError && (
                  <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}
                    className="flex items-center gap-1.5 mt-1.5">
                    <AlertTriangle size={11} style={{ color: '#fb7185' }} />
                    <p className="text-[10px]" style={{ color: '#fda4af' }}>{addressError}</p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {withdrawAmt > 0 && (
              <div className="rounded-xl p-3 space-y-1.5 text-xs"
                style={{ background: 'rgba(0,0,0,0.3)', border: '1px solid rgba(255,255,255,0.06)' }}>
                <div className="flex justify-between" style={{ color: 'rgba(148,163,184,0.7)' }}>
                  <span>Amount</span>
                  <span>{withdrawAmt} {sym} <span style={{ color: 'rgba(148,163,184,0.55)' }}>(${(withdrawAmt * usdPerSc).toFixed(2)})</span></span>
                </div>
                <div className="flex justify-between" style={{ color: 'rgba(148,163,184,0.7)' }}>
                  <span>Fee (2%, min 50)</span>
                  <span style={{ color: '#f87171' }}>−{withdrawFee.toFixed(2)} {sym}</span>
                </div>
                <div className="flex justify-between" style={{ color: 'rgba(148,163,184,0.7)' }}>
                  <span>Net</span><span>{withdrawNet.toFixed(2)} {sym}</span>
                </div>
                {isTestnet && withdrawAmt > 0 && (
                  <>
                    <div className="flex justify-between" style={{ color: 'rgba(245,158,11,0.7)' }}>
                      <span>L1 Commission (5%)</span>
                      <span>+{(withdrawAmt * 0.05).toFixed(2)} {sym}</span>
                    </div>
                    <div className="flex justify-between" style={{ color: 'rgba(245,158,11,0.55)' }}>
                      <span>L2 Commission (2% of L1)</span>
                      <span>+{(withdrawAmt * 0.05 * 0.02).toFixed(4)} {sym}</span>
                    </div>
                  </>
                )}
                <div className="flex justify-between font-black text-white pt-1.5"
                  style={{ borderTop: '1px solid rgba(255,255,255,0.06)' }}>
                  <span>You receive</span>
                  <span style={{ color: '#10b981' }}>
                    {isTestnet ? `${withdrawTon} TON (simulated)` : `${withdrawTon} TON ≈ $${withdrawUsd.toFixed(2)}`}
                  </span>
                </div>
              </div>
            )}

            <button
              onClick={isTestnet ? handleTestnetWithdraw : handleWithdraw}
              disabled={isWithdrawDisabled}
              className="w-full py-3.5 rounded-xl font-black text-sm transition-all"
              style={isWithdrawDisabled ? {
                background: 'rgba(255,255,255,0.04)', color: 'rgba(100,100,120,0.5)', cursor: 'not-allowed',
              } : isTestnet ? {
                background: 'linear-gradient(135deg, #92400e, #f59e0b)',
                color: '#0a0a0f', fontFamily: 'Orbitron, sans-serif', letterSpacing: '0.08em',
                boxShadow: '0 0 24px rgba(245,158,11,0.35)',
              } : {
                background: 'linear-gradient(135deg, #047857, #10b981)',
                color: '#fff', fontFamily: 'Orbitron, sans-serif', letterSpacing: '0.08em',
                boxShadow: '0 0 24px rgba(5,150,105,0.4)',
              }}>
              <Send size={14} className="inline mr-2 mb-0.5"/>
              {busy ? 'SIMULATING…' : isTestnet ? 'SIMULATE TESTNET TX' : 'REQUEST WITHDRAWAL'}
            </button>
          </div>

          {/* Testnet tx history */}
          {isTestnet && testnetTxs.length > 0 && (
            <div>
              <p className="text-[9px] font-black uppercase tracking-widest px-1 mb-2"
                style={{ color: 'rgba(251,191,36,0.6)' }}>Simulated TX History</p>
              <div className="rounded-2xl overflow-hidden"
                style={{ border: '1px solid rgba(251,191,36,0.2)', background: 'rgba(0,0,0,0.3)' }}>
                {testnetTxs.slice(0, 5).map((tx, i) => (
                  <div key={tx.id}
                    className={`flex items-center gap-3 px-4 py-3 ${i < Math.min(testnetTxs.length, 5) - 1 ? 'border-b' : ''}`}
                    style={{ borderColor: 'rgba(255,255,255,0.04)' }}>
                    <div className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0"
                      style={{ background: 'rgba(251,191,36,0.1)', border: '1px solid rgba(251,191,36,0.22)' }}>
                      <Send size={11} style={{ color: '#fbbf24' }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-[10px] font-bold text-white font-mono truncate">{tx.tx_hash}</p>
                      <p className="text-[9px]" style={{ color: 'rgba(148,163,184,0.55)' }}>
                        {tx.amount_ton} TON · {new Date(tx.simulated_at).toLocaleString()}
                      </p>
                    </div>
                    <a href={`${testnetExplorer}${tx.tx_hash}`} target="_blank" rel="noopener noreferrer">
                      <ExternalLink size={11} style={{ color: 'rgba(34,211,238,0.6)' }} />
                    </a>
                  </div>
                ))}
              </div>
            </div>
          )}
        </motion.div>
      )}

      {/* ── HISTORY tab ─────────────────────────────────────────────────────── */}
      {tab === 'history' && (
        <motion.div variants={item}>
          <div className="glass-card rounded-2xl overflow-hidden">
            {ledger.length === 0 && (
              <p className="px-4 py-6 text-center text-sm" style={{ color: 'rgba(148,163,184,0.72)' }}>
                No transactions yet.
              </p>
            )}
            {ledger.map((row, i) => {
              const isCredit = row.direction === 'credit';
              return (
                <div key={row.id || i}
                  className={`flex items-center gap-3 px-4 py-3 ${i < ledger.length - 1 ? 'border-b' : ''}`}
                  style={{ borderColor: 'rgba(255,255,255,0.05)' }}>
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                    style={isCredit
                      ? { background: 'rgba(16,185,129,0.1)', border: '1px solid rgba(16,185,129,0.18)' }
                      : { background: 'rgba(244,63,94,0.1)',  border: '1px solid rgba(244,63,94,0.18)' }}>
                    {isCredit
                      ? <ArrowDownLeft size={12} className="text-emerald-400" />
                      : <ArrowUpRight  size={12} className="text-rose-400" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-white capitalize truncate">{(row.category || 'transaction').replace(/_/g, ' ')}</p>
                    <p className="text-[10px] truncate" style={{ color: 'rgba(148,163,184,0.75)' }}>
                      {row.description || new Date(row.created_at).toLocaleString()}
                    </p>
                  </div>
                  <p className="font-black text-xs" style={{ color: isCredit ? '#10b981' : '#f87171' }}>
                    {isCredit ? '+' : '-'}{Number(row.amount_token || row.amount_usd || 0).toLocaleString()} {sym}
                  </p>
                </div>
              );
            })}
          </div>
        </motion.div>
      )}
    </motion.div>
  );
}

function LifetimeStat({ label, value, color }) {
  return (
    <div className="rounded-2xl p-3 relative overflow-hidden"
      style={{ background: `${color}10`, border: `1px solid ${color}30` }}>
      <p className="font-orbitron text-sm font-black leading-none" style={{ color }}>{value}</p>
      <p className="text-[9px] font-bold uppercase tracking-widest mt-1.5" style={{ color: 'rgba(148,163,184,0.7)' }}>
        {label}
      </p>
    </div>
  );
}
