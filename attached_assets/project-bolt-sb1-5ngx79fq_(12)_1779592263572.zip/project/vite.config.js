import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'
import compression from 'vite-plugin-compression'

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '')
  const supabaseUrl = env.VITE_SUPABASE_URL || ''

  return {
    plugins: [
      react(),
      compression({ algorithm: 'gzip', ext: '.gz', threshold: 1024 }),
      compression({ algorithm: 'brotliCompress', ext: '.br', threshold: 1024 }),
    ],
    publicDir: 'static',
    server: {
      allowedHosts: 'all',
      proxy: supabaseUrl ? {
        '/supabase-proxy': {
          target: supabaseUrl,
          changeOrigin: true,
          secure: false,
          rewrite: (path) => path.replace(/^\/supabase-proxy/, ''),
          configure: (proxy) => {
            proxy.on('error', () => {});
          },
        },
      } : {},
    },
    build: {
      target: 'es2020',
      cssCodeSplit: true,
      sourcemap: false,
      minify: 'esbuild',
      rollupOptions: {
        input: {
          main:        'index.html',
          manager:     'manager.html',
          influencers: 'influencers.html',
        },
        output: {
          manualChunks(id) {
            if (!id.includes('node_modules')) return;
            if (id.includes('framer-motion')) return 'vendor-motion';
            if (id.includes('@supabase')) return 'vendor-supabase';
            if (id.includes('lucide-react')) return 'vendor-icons';
            if (id.includes('zustand')) return 'vendor-state';
            if (id.includes('react-dom')) return 'vendor-react';
            if (id.includes('react/') || id.endsWith('/react')) return 'vendor-react';
            return 'vendor';
          },
        },
      },
    },
  }
})
